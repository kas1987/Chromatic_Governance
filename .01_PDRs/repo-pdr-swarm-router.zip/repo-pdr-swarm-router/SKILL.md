---
name: repo-pdr-swarm-router
description: ingest, decompose, govern, and route large repository pdr packages into chromatic ai harness compliant agent work queues. use when the user provides or references repo pdr packages, repo audit bundles, project design records, implementation plans, backlog packs, zipped repos, markdown suites, or governance artifacts and wants them parsed, scored, split into agent assignments, dispatched through a router, checked against chromatic harness best practices, or converted into swarm-ready handoffs.
---

# Repo PDR Swarm Router

## Mission
Turn large Repo PDR packages into governed, agent-routable work. Preserve the user's router as the authority, enforce Chromatic AI Harness practices, and produce audit-ready queue items rather than loose summaries.

## Operating Rule
Never treat a Repo PDR as a normal document summary. Always convert it into a controlled execution system:

1. intake and inventory the package
2. classify every artifact by role and risk
3. extract requirements, decisions, constraints, open questions, and implementation targets
4. map work to the router and agent roles
5. enforce governance, evidence, and stop conditions
6. output dispatchable work packets with acceptance criteria

## Required Workflow

### 1. Intake the package
Use available file, connector, repo, or archive tools to inspect the supplied PDR package. If a local directory or extracted archive is available, optionally run:

```bash
python scripts/parse_repo_pdr.py --input <path> --output <output-dir>
```

The script creates a manifest, queue seed, risk register, evidence map, and dispatch board. Use it when there are many files, nested folders, or mixed markdown/json/yaml/python assets.

### 2. Build the package inventory
Create or update these objects:

- `pdr_manifest`: all files, paths, inferred purpose, artifact class, and evidence status
- `decision_register`: decisions already made, unresolved decisions, and contradictions
- `constraint_register`: non-negotiables, router rules, governance rules, runtime limits
- `work_queue`: actionable tasks, dependencies, owners, priority, and stop conditions
- `risk_register`: drift, duplication, security, architectural, governance, and execution risks

Use `references/pdr-intake.md` for artifact classification and extraction rules.

### 3. Route through the Chromatic router
Respect the user's router before inventing new roles. If no explicit router is present, apply the default router in `references/router-map.md`.

Default routing:

- sentinel: code quality, tests, CI, security, failure modes
- auditor: governance, evidence, contradictions, acceptance gates
- chainbreaker: blockers, ambiguity, cyclic dependencies, brittle workflows
- quartermaster: assets, manifests, dependency inventories, package readiness
- cartographer: repo tree, folder standards, file placement, architecture maps
- financier: cost, token budget, cloud spend, operational efficiency
- archivist: memory, decisions, logs, versioning, changelogs
- janitor: cleanup, duplicates, stale files, root hygiene

### 4. Enforce governance gates
Apply `references/governance-gates.md` before dispatch:

- source-of-truth gate
- router-alignment gate
- evidence gate
- dependency gate
- safety/security gate
- acceptance-criteria gate
- stop-condition gate
- repo-tree gate

Do not dispatch work that lacks clear evidence, owner, acceptance criteria, and stop condition. Mark it `blocked` or `needs-human-decision` instead.

### 5. Produce swarm-ready outputs
For every PDR intake, produce these outputs unless the user asks for a narrower deliverable:

1. Executive intake summary
2. PDR manifest
3. Agent dispatch board
4. Dependency graph or dependency list
5. Governance/risk register
6. Priority queue with next 3 to 10 actions
7. Handoff packets for each assigned agent

Use `templates/agent-handoff.md` and `templates/dispatch-board.md`.

## Output Standards

### Dispatch packet minimum fields
Every agent task must include:

- `task_id`
- `agent_role`
- `mission`
- `source_files`
- `evidence_required`
- `allowed_actions`
- `blocked_actions`
- `acceptance_criteria`
- `stop_condition`
- `handoff_target`
- `priority`
- `status`

### Priority scoring
Use this default scoring when the user has not supplied one:

- P0: blocks safe intake, governance, security, or router operation
- P1: blocks execution of multiple downstream tasks
- P2: improves correctness, reliability, or traceability
- P3: cleanup, polish, documentation, optional enhancement

### Status values
Use only:

- `ready`
- `blocked`
- `needs-human-decision`
- `in-progress`
- `review-required`
- `done`

## ChromaticTrees Rule
Treat `CHROMATIC_TREES.md` as the source of truth for repo tree rules when present. Use the machine-readable worktree map as the structural mirror. Memory and learning logs are supporting evidence, not replacements for source-of-truth rules. Claude, Cursor, Codex, Agents, and other assistant files should defer to ChromaticTrees instead of duplicating conflicting tree rules.

If `CHROMATIC_TREES.md` is missing from a repo governance package, recommend creating it and include a task for cartographer.

## Reference Loading
Load only the reference needed for the current task:

- `references/pdr-intake.md`: large package intake, artifact classification, extraction rules
- `references/router-map.md`: agent roles, routing rules, conflict resolution
- `references/governance-gates.md`: quality gates and blocked-work rules
- `references/output-contracts.md`: exact output schemas and handoff templates
- `references/chromatic-trees.md`: repo tree governance, source-of-truth hierarchy

## Failure Handling
If package contents are too large or inaccessible, do not guess. Produce a partial manifest of what was inspected, identify missing inputs, and create a `blocked` queue item with the exact missing evidence.

If two files conflict, do not merge silently. Record the contradiction, identify the stronger source based on hierarchy, and route a decision task to auditor or the user.
