#!/usr/bin/env bash
set -euo pipefail
echo '[data-research-family] advisory hook: scripts/research-scope.sh' >&2
exit 0
