# Data Research Family Policy

## Boundary

Evidence gathering, source scans, benchmarks, documentation digests, API change watches, and citation audits.

## Default stance

- Load this plugin only when its scope directly applies.
- Prefer least privilege.
- Escalate to human review before destructive, security-sensitive, release, or external-system actions.
- Keep outputs auditable and handoff-ready.
