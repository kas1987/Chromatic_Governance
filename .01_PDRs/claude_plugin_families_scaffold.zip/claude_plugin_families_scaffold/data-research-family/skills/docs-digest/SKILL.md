---
name: docs-digest
description: Placeholder for the Docs Digest workflow in the Data Research Family plugin. Invoke when the user asks for docs digest within this plugin family scope.
---

# Docs Digest

## Status

Placeholder scaffold. Build the detailed skill procedure in the next phase.

## Intended purpose

Evidence gathering, source scans, benchmarks, documentation digests, API change watches, and citation audits.

## Required future sections

1. Trigger conditions
2. Inputs and assumptions
3. Step-by-step procedure
4. Guardrails and escalation conditions
5. Expected outputs
6. Handoff format
7. Examples

## Current behavior guidance

Until this skill is implemented, treat it as an intent marker only. Do not perform destructive actions or external-system operations solely because this placeholder exists.
