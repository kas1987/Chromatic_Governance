# Data Research Family

Evidence gathering, source scans, benchmarks, documentation digests, API change watches, and citation audits.

## Skills

- `source-scan`
- `evidence-brief`
- `benchmark-compare`
- `market-scan`
- `docs-digest`
- `api-change-watch`
- `citation-audit`
- `research-handoff`

## Agents

- `research-analyst` - Gathers and summarizes evidence without modifying implementation files by default.

## Status

Scaffold complete. Skill procedures are placeholders and should be filled before broad use.
