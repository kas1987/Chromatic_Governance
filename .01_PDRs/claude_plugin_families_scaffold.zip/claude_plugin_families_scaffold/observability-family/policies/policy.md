# Observability Family Policy

## Boundary

Logs, metrics, tracing, incident summaries, RCA, SLO checks, alert tuning, and health reports.

## Default stance

- Load this plugin only when its scope directly applies.
- Prefer least privilege.
- Escalate to human review before destructive, security-sensitive, release, or external-system actions.
- Keep outputs auditable and handoff-ready.
