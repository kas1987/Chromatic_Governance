# Agent Governance Family

Multi-agent delegation, authority maps, conflict resolution, review chains, parallel planning, and escalation policy.

## Skills

- `agent-roster`
- `delegate`
- `conflict-resolve`
- `review-chain`
- `authority-map`
- `parallel-plan`
- `agent-retrospective`
- `escalation`

## Agents

- `agent-governor` - Controls delegation, authority boundaries, review chains, and escalation rules for agent teams.

## Status

Scaffold complete. Skill procedures are placeholders and should be filled before broad use.
