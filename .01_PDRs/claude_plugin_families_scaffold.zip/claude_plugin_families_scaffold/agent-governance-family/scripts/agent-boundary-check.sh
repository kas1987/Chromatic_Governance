#!/usr/bin/env bash
set -euo pipefail
echo '[agent-governance-family] advisory hook: scripts/agent-boundary-check.sh' >&2
exit 0
