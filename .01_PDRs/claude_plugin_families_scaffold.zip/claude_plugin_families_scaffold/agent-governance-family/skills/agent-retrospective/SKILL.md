---
name: agent-retrospective
description: Placeholder for the Agent Retrospective workflow in the Agent Governance Family plugin. Invoke when the user asks for agent retrospective within this plugin family scope.
---

# Agent Retrospective

## Status

Placeholder scaffold. Build the detailed skill procedure in the next phase.

## Intended purpose

Multi-agent delegation, authority maps, conflict resolution, review chains, parallel planning, and escalation policy.

## Required future sections

1. Trigger conditions
2. Inputs and assumptions
3. Step-by-step procedure
4. Guardrails and escalation conditions
5. Expected outputs
6. Handoff format
7. Examples

## Current behavior guidance

Until this skill is implemented, treat it as an intent marker only. Do not perform destructive actions or external-system operations solely because this placeholder exists.
