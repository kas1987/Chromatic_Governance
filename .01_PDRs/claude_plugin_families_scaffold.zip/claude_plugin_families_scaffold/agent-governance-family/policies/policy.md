# Agent Governance Family Policy

## Boundary

Multi-agent delegation, authority maps, conflict resolution, review chains, parallel planning, and escalation policy.

## Default stance

- Load this plugin only when its scope directly applies.
- Prefer least privilege.
- Escalate to human review before destructive, security-sensitive, release, or external-system actions.
- Keep outputs auditable and handoff-ready.
