# Toolchain Family Policy

## Boundary

Infrastructure and authoring utilities for agent workspaces, handoffs, audits, harvesting, and repo operations.

## Default stance

- Load this plugin only when its scope directly applies.
- Prefer least privilege.
- Escalate to human review before destructive, security-sensitive, release, or external-system actions.
- Keep outputs auditable and handoff-ready.
