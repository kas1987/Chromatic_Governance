# Toolchain Family

Infrastructure and authoring utilities for agent workspaces, handoffs, audits, harvesting, and repo operations.

## Skills

- `handoff`
- `status`
- `harvest`
- `harvest-insights`
- `system-audit`
- `using-git-worktrees`
- `writing-skills`

## Agents

- `toolchain-operator` - Maintains workspace hygiene, worktree usage, status reports, and handoff packs.

## Status

Scaffold complete. Skill procedures are placeholders and should be filled before broad use.
