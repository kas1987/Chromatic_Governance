---
name: using-git-worktrees
description: Placeholder for the Using Git Worktrees workflow in the Toolchain Family plugin. Invoke when the user asks for using git worktrees within this plugin family scope.
---

# Using Git Worktrees

## Status

Placeholder scaffold. Build the detailed skill procedure in the next phase.

## Intended purpose

Infrastructure and authoring utilities for agent workspaces, handoffs, audits, harvesting, and repo operations.

## Required future sections

1. Trigger conditions
2. Inputs and assumptions
3. Step-by-step procedure
4. Guardrails and escalation conditions
5. Expected outputs
6. Handoff format
7. Examples

## Current behavior guidance

Until this skill is implemented, treat it as an intent marker only. Do not perform destructive actions or external-system operations solely because this placeholder exists.
