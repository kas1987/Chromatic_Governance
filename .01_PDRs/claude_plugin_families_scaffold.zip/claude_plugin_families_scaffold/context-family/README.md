# Context Family

Context, memory, decision log, source-of-truth, and session handoff controls.

## Skills

- `context-map`
- `memory-sync`
- `session-brief`
- `decision-log`
- `context-prune`
- `handoff-pack`
- `source-of-truth-audit`
- `onboarding-brief`

## Agents

- `context-steward` - Keeps project context compact, current, source-backed, and ready for handoff.

## Status

Scaffold complete. Skill procedures are placeholders and should be filled before broad use.
