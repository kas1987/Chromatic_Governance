# PDR - Plugin Design Review

PDR meaning in this pack: Plugin Design Review. Use this before installing, publishing, or giving agents broad access to these plugin families.

## Decision summary

Status: scaffold ready for skill-body implementation.

Decision: use multiple scoped plugin families instead of one universal plugin. Plugins define mission scope; skills define repeatable workflows; agents provide bounded reasoning roles; hooks enforce lifecycle checks; MCP remains optional for external-system access.

## Review checklist

### 1. Structure

- [ ] `.claude-plugin/plugin.json` exists for each plugin.
- [ ] Component directories are at plugin root, not inside `.claude-plugin/`.
- [ ] No empty placeholder directory is required for runtime operation.
- [ ] Paths are relative or use `${CLAUDE_PLUGIN_ROOT}`.
- [ ] No secrets, tokens, `.env`, or machine-specific absolute paths are included.

### 2. Scope discipline

- [ ] Each plugin has a clear mission boundary.
- [ ] No plugin duplicates another plugin's core authority.
- [ ] Skills are not overloaded with unrelated responsibilities.
- [ ] Read-only families stay read-only by default unless explicitly escalated.

### 3. Agent authority

- [ ] Each agent has a narrow description and bounded tool policy.
- [ ] High-risk agents avoid broad write/edit access by default.
- [ ] Multi-agent workflows define a review chain before parallel execution.
- [ ] Worktree isolation is used when concurrent code changes are expected.

### 4. Hooks

- [ ] Hooks are advisory or blocking only where justified.
- [ ] Hook scripts are deterministic, fast, and fail safely.
- [ ] Hooks do not leak secrets or send data externally without explicit config.
- [ ] Hooks that run shell commands are reviewed before enabling.

### 5. MCP boundary

- [ ] MCP servers are not bundled unless the plugin truly needs live external access.
- [ ] MCP credentials are requested via user config, not hardcoded.
- [ ] Plugins remain useful without MCP where possible.

### 6. Quality gates

- [ ] `qa-eval-family` defines acceptance gates before implementation work.
- [ ] `security-family` runs on any plugin that touches commands, hooks, MCP, or external data.
- [ ] `context-family` checks that persistent project context is current and non-contradictory.
- [ ] `release-family` controls deployment, rollback, and post-release monitoring.

## Risks

| Risk | Impact | Mitigation |
|---|---|---|
| Plugin bloat | Agents inherit irrelevant instructions and authority | Load by mission scope only |
| Duplicate skills | Conflicting behavior and confusing triggers | Use `PLUGIN_INDEX.md` and deduplicate during skill-writing |
| Unsafe hooks | Shell commands execute too broadly | Keep hooks minimal; review scripts before enablement |
| MCP overuse | External access expands attack surface | Treat MCP as optional capability, not default |
| Weak context | Agents build from stale assumptions | Use `context-family` as a recurring gate |

## Next work package

1. Fill each placeholder `SKILL.md` with trigger conditions, procedure, inputs, outputs, and guardrails.
2. Replace advisory shell scripts with real checks only where useful.
3. Run `claude plugin validate ./<plugin>` on each plugin.
4. Decide which plugins should be default-enabled versus opt-in.
5. Add marketplace metadata only after the local developer workflow is stable.
