# QA Eval Family

Testing, acceptance criteria, regression harnesses, LLM/agent evals, golden cases, and failure analysis.

## Skills

- `acceptance-criteria`
- `test-plan`
- `regression-harness`
- `eval-suite`
- `golden-cases`
- `failure-analysis`
- `coverage-review`
- `chaos-test`

## Agents

- `qa-evaluator` - Defines and runs quality gates, tests, regressions, and eval plans.

## Status

Scaffold complete. Skill procedures are placeholders and should be filled before broad use.
