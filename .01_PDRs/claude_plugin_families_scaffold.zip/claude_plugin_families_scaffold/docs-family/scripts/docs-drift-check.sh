#!/usr/bin/env bash
set -euo pipefail
echo '[docs-family] advisory hook: scripts/docs-drift-check.sh' >&2
exit 0
