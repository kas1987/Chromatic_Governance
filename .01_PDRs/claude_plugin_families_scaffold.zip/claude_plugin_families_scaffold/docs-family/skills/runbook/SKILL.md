---
name: runbook
description: Placeholder for the Runbook workflow in the Docs Family plugin. Invoke when the user asks for runbook within this plugin family scope.
---

# Runbook

## Status

Placeholder scaffold. Build the detailed skill procedure in the next phase.

## Intended purpose

Documentation operations for README, API docs, runbooks, dev guides, troubleshooting, diagrams, and doc audits.

## Required future sections

1. Trigger conditions
2. Inputs and assumptions
3. Step-by-step procedure
4. Guardrails and escalation conditions
5. Expected outputs
6. Handoff format
7. Examples

## Current behavior guidance

Until this skill is implemented, treat it as an intent marker only. Do not perform destructive actions or external-system operations solely because this placeholder exists.
