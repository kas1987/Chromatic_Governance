# Docs Family

Documentation operations for README, API docs, runbooks, dev guides, troubleshooting, diagrams, and doc audits.

## Skills

- `readme-refresh`
- `api-docs`
- `runbook`
- `dev-guide`
- `troubleshooting`
- `diagram-plan`
- `doc-audit`
- `doc-sync`

## Agents

- `docs-maintainer` - Keeps docs aligned with implementation, operations, and user-facing behavior.

## Status

Scaffold complete. Skill procedures are placeholders and should be filled before broad use.
