# Docs Family Policy

## Boundary

Documentation operations for README, API docs, runbooks, dev guides, troubleshooting, diagrams, and doc audits.

## Default stance

- Load this plugin only when its scope directly applies.
- Prefer least privilege.
- Escalate to human review before destructive, security-sensitive, release, or external-system actions.
- Keep outputs auditable and handoff-ready.
