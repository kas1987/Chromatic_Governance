#!/usr/bin/env bash
set -euo pipefail
root="${1:-.}"
fail=0
for plugin in "$root"/*; do
  [ -d "$plugin" ] || continue
  name="$(basename "$plugin")"
  case "$name" in scripts) continue ;; esac
  if [ ! -f "$plugin/.claude-plugin/plugin.json" ]; then
    echo "FAIL $name: missing .claude-plugin/plugin.json"
    fail=1
    continue
  fi
  if [ ! -f "$plugin/README.md" ]; then
    echo "FAIL $name: missing README.md"
    fail=1
  fi
  python3 -m json.tool "$plugin/.claude-plugin/plugin.json" >/dev/null || fail=1
  echo "OK $name"
done
exit "$fail"
