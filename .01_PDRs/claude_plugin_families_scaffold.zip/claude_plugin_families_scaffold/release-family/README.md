# Release Family

Release planning, changelogs, versioning, rollout, deployment checks, rollback, and post-release monitoring.

## Skills

- `release-plan`
- `changelog`
- `version-bump`
- `release-notes`
- `migration-check`
- `rollback-plan`
- `deploy-checklist`
- `post-release-monitor`

## Agents

- `release-manager` - Controls release gates, versioning, rollback plans, and post-release monitoring.

## Status

Scaffold complete. Skill procedures are placeholders and should be filled before broad use.
