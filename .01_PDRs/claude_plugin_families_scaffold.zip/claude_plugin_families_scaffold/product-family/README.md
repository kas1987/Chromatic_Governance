# Product Family

Requirements, user stories, MVP planning, prioritization, UX critique, and feedback-to-backlog conversion.

## Skills

- `user-story`
- `requirements`
- `scope-cut`
- `mvp-plan`
- `roadmap`
- `prioritize`
- `ux-critique`
- `feedback-loop`

## Agents

- `product-strategist` - Translates ideas and user feedback into scoped product decisions and delivery priorities.

## Status

Scaffold complete. Skill procedures are placeholders and should be filled before broad use.
