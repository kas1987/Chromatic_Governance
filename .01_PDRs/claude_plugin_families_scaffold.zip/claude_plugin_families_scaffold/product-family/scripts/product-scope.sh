#!/usr/bin/env bash
set -euo pipefail
echo '[product-family] advisory hook: scripts/product-scope.sh' >&2
exit 0
