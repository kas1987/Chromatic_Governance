# Product Family Policy

## Boundary

Requirements, user stories, MVP planning, prioritization, UX critique, and feedback-to-backlog conversion.

## Default stance

- Load this plugin only when its scope directly applies.
- Prefer least privilege.
- Escalate to human review before destructive, security-sensitive, release, or external-system actions.
- Keep outputs auditable and handoff-ready.
