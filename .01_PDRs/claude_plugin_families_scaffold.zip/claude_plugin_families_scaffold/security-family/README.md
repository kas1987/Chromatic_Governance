# Security Family

Security, trust-boundary, secrets, prompt-injection, and permission review controls for agentic development.

## Skills

- `threat-model`
- `secrets-audit`
- `dependency-risk`
- `permissions-plan`
- `sandbox-check`
- `prompt-injection-review`
- `security-pr`
- `hardening-pass`

## Agents

- `security-reviewer` - Reviews changes for secrets, supply-chain risk, prompt injection, and unsafe tool use.

## Status

Scaffold complete. Skill procedures are placeholders and should be filled before broad use.
