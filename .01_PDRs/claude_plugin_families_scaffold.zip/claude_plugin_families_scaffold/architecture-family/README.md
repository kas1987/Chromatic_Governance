# Architecture Family

Design governance for architecture, interfaces, module boundaries, ADRs, migrations, and technical debt.

## Skills

- `architecture-review`
- `design-doc`
- `adr-create`
- `interface-contracts`
- `module-boundaries`
- `migration-plan`
- `scalability-review`
- `technical-debt-map`

## Agents

- `architect` - Evaluates system design, boundaries, scalability, and long-term maintainability.

## Status

Scaffold complete. Skill procedures are placeholders and should be filled before broad use.
