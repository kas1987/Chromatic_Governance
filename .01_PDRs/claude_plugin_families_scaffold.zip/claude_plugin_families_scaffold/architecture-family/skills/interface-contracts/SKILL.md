---
name: interface-contracts
description: Placeholder for the Interface Contracts workflow in the Architecture Family plugin. Invoke when the user asks for interface contracts within this plugin family scope.
---

# Interface Contracts

## Status

Placeholder scaffold. Build the detailed skill procedure in the next phase.

## Intended purpose

Design governance for architecture, interfaces, module boundaries, ADRs, migrations, and technical debt.

## Required future sections

1. Trigger conditions
2. Inputs and assumptions
3. Step-by-step procedure
4. Guardrails and escalation conditions
5. Expected outputs
6. Handoff format
7. Examples

## Current behavior guidance

Until this skill is implemented, treat it as an intent marker only. Do not perform destructive actions or external-system operations solely because this placeholder exists.
