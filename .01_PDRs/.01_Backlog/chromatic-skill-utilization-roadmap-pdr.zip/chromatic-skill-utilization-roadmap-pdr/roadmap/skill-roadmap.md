# Skill Roadmap

## Purpose
Sequence the evolution of the skill ecosystem into a small, governed, cross-LLM operating stack.

## Phase 0: Baseline Control

### Objectives
- Confirm current skill inventory.
- Lock the trigger map.
- Define governance standard.
- Stop uncontrolled skill sprawl.

### Deliverables
- `current-skill-inventory.md`
- `skill-trigger-map.md`
- `skill-governance-standard.md`
- `skill-review-checklist.md`

### Exit Criteria
- Every known skill has a purpose, tier, and decision.
- Every proposed skill has a reason and priority.

## Phase 1: IDE Execution Bridge

### Build
`llm-ide-handoff-packager`

### Why First
The current router can produce good work packets, but IDE agents need specific handoff files, allowed/blocked actions, acceptance criteria, and stop conditions.

### Deliverables
- Skill package: `skill.zip`
- Templates:
  - `codex-handoff.md`
  - `cursor-task.md`
  - `claude-project-context.md`
  - `gemini-review-brief.md`
  - `github-issue.md`
- Reference:
  - `ide-handoff-modes.md`

### Exit Criteria
- A PDR/router queue can be converted into at least three target formats: Cursor, Codex, and GitHub Issue.

## Phase 2: GitHub Org Governance

### Build
`github-org-governance-manager`

### Why Second
The user is actively migrating repos from personal account ownership to the Poly-Chromatic organization and needs repeatable governance controls.

### Deliverables
- Repo transfer plan template.
- Org settings checklist.
- Branch protection/ruleset checklist.
- Repo permission matrix.
- Post-transfer validation runbook.

### Exit Criteria
- Any personal-account repo can be assessed and migrated into the org with a repeatable checklist.

## Phase 3: Durable Memory Registration

### Build
`chromatic-memory-registrar`

### Why Third
The user's project system is broad and fast-moving. Durable project state, decisions, changelogs, and next actions need a consistent update mechanism.

### Deliverables
- `PROJECT_STATE.md` template.
- `DECISIONS.md` template.
- `CHANGELOG.md` template.
- `NEXT_ACTIONS.md` template.
- Memory registration rules.

### Exit Criteria
- Major repo/PDR/agent events can update durable memory without losing context or creating contradictory state.

## Phase 4: Router Upgrade

### Improve
`repo-pdr-swarm-router`

### Add
- External LLM handoff reference.
- IDE output contract reference.
- GitHub Issue output mode.
- Cursor/Codex/Claude/Gemini routing notes.

### Exit Criteria
- Router outputs cleanly feed `llm-ide-handoff-packager`.

## Phase 5: Periodic Audit Loop

### Use
`skill-agent-utilization-auditor`

### Cadence
Monthly or after major project milestones.

### Exit Criteria
- Skills are classified as keep, improve, merge, retire, or build.
- Inactive/overlapping agents are flagged.
- Governance drift is captured.

## Roadmap Summary

| Phase | Priority | Outcome |
|---|---:|---|
| Phase 0 | P0 | Skill inventory and governance baseline. |
| Phase 1 | P1 | IDE/LLM execution bridge. |
| Phase 2 | P1 | GitHub org governance skill. |
| Phase 3 | P1 | Durable memory registration. |
| Phase 4 | P2 | Router upgrade. |
| Phase 5 | P2 | Recurring utilization audit. |
