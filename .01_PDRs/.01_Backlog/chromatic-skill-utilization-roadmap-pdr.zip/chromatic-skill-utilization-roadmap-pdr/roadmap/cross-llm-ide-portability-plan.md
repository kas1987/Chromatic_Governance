# Cross-LLM and IDE Portability Plan

## Purpose
Make Poly-Chromatic skills useful beyond ChatGPT by producing Markdown-first handoffs that can be consumed by Claude, Cursor, Codex, Gemini, local LLMs, GitHub Issues, and repo-native agents.

## Portability Principle
Skills should not depend on hidden ChatGPT-only context when producing outputs intended for other systems. Every handoff must include context, objective, inputs, constraints, allowed actions, blocked actions, acceptance criteria, and stop conditions.

## Target Environments

| Environment | Primary Use | Required Output Style |
|---|---|---|
| ChatGPT | Tool-aware orchestration, artifact creation, connector use. | PDR, queue, synthesis, package. |
| Claude | Long context review, strategy, requirements, documentation, critique. | Context-rich review pack. |
| Cursor | Repo implementation and iterative file edits. | File-specific task packet and rules. |
| Codex | Code changes, tests, PR-ready implementation. | Exact implementation handoff with tests and constraints. |
| Gemini | Multimodal review, alternative reasoning, broad comparisons. | Review brief and evidence map. |
| Local LLM / Ollama / LM Studio | Cheap repeated triage/classification/offline summarization. | Compact task JSON/Markdown. |
| GitHub Issues | Durable task tracking and collaboration. | Issue-ready title/body/labels/acceptance criteria. |

## Universal Handoff Contract

Every portable handoff must include:

```yaml
task_id: string
title: string
source_project: string
source_files: list
objective: string
context: string
allowed_actions: list
blocked_actions: list
inputs_required: list
outputs_required: list
acceptance_criteria: list
stop_conditions: list
review_gate: string
handoff_target: string
priority: p0|p1|p2|p3
status: ready|blocked|needs-human-decision|in-progress|review-required|done
```

## Output Modes

### Cursor Mode
- Include repo path assumptions.
- Include exact files to inspect first.
- Include edit scope.
- Include tests/validation commands if known.
- Include stop conditions when files are missing or architecture conflicts appear.

### Codex Mode
- Include implementation goal.
- Include explicit diff boundaries.
- Include test command.
- Include PR summary draft.
- Include failure handling.

### Claude Mode
- Include longer project background.
- Include decision history.
- Include review questions.
- Include critique and alternatives request.

### Gemini Mode
- Include broad review target.
- Include comparison dimensions.
- Include visual/multimodal references if relevant.

### GitHub Issue Mode
- Include concise title.
- Include labels.
- Include linked source docs.
- Include acceptance checklist.
- Include owner/agent role.

### Local LLM Mode
- Keep compact.
- Avoid large references.
- Use classification/routing tasks.
- Prefer JSONL-friendly outputs.

## Integration with `repo-pdr-swarm-router`

The router remains responsible for extracting and governing work. The handoff packager is responsible for converting governed work into target-specific execution formats.

```text
PDR package -> repo-pdr-swarm-router -> dispatch board -> llm-ide-handoff-packager -> target handoffs
```

## Validation Rules

A handoff is valid only if:

- It can be executed without relying on hidden chat context.
- It has a clear stop condition.
- It names allowed and blocked actions.
- It defines output expectations.
- It contains enough evidence/source references for the target agent to begin.
- It does not authorize destructive changes unless explicitly approved.
