# Agent Handoff: Build `llm-ide-handoff-packager`

## Role
You are acting as a skill designer and packager.

## Objective
Create a new skill named `llm-ide-handoff-packager` that converts PDR/router/queue outputs into execution-ready handoff packs for Cursor, Codex, Claude, Gemini, local LLMs, and GitHub Issues.

## Context
The Poly-Chromatic system already has `repo-pdr-swarm-router`, which can convert PDR packages into governed work packets. The missing bridge is target-specific output packaging for IDEs and other LLMs.

## Inputs
- `skill-specs/llm-ide-handoff-packager.spec.md`
- `roadmap/cross-llm-ide-portability-plan.md`
- `templates/ide-handoff-template.md`
- `templates/agent-handoff-template.md`

## Expected Skill Resources

```text
llm-ide-handoff-packager/
  SKILL.md
  agents/openai.yaml
  references/
    target-modes.md
    output-contracts.md
    validation-rules.md
  templates/
    cursor-task.md
    codex-handoff.md
    claude-project-context.md
    gemini-review-brief.md
    github-issue.md
    local-llm-task.md
```

## Instructions
1. Use `skill-creator` to create the skill.
2. Ask only for missing critical details if required.
3. Keep `SKILL.md` compact and trigger-focused.
4. Put target-specific details in references/templates.
5. Ensure outputs include objective, context, allowed actions, blocked actions, acceptance criteria, and stop conditions.
6. Package the result as `skill.zip`.

## Acceptance Criteria
- Skill validates successfully.
- Package is named `skill.zip`.
- Supports at least Cursor, Codex, Claude, GitHub Issue, and local LLM modes.
- Does not rely on hidden ChatGPT context.
- Uses portable Markdown output.

## Stop Conditions
Stop if:
- Required target environments are unclear.
- The skill would exceed package size limits.
- The expected input/output contract cannot be defined.
