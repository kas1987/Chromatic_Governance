# Agent Handoff: Build `chromatic-memory-registrar`

## Role
You are acting as a skill designer and project-memory governance architect.

## Objective
Create a new skill named `chromatic-memory-registrar` that captures durable decisions, project state, changelog entries, next actions, and source-of-truth references after major repo/PDR/agent events.

## Context
The user's projects move quickly across many conversations, repos, agents, and artifacts. Major decisions and state transitions need a reliable registration process.

## Inputs
- `skill-specs/chromatic-memory-registrar.spec.md`
- `docs/PDR-001-skill-utilization-roadmap.md`
- Existing project-state conventions if available.

## Expected Skill Resources

```text
chromatic-memory-registrar/
  SKILL.md
  agents/openai.yaml
  references/
    memory-rules.md
    source-of-truth-hierarchy.md
    update-protocol.md
  templates/
    PROJECT_STATE.md
    DECISIONS.md
    CHANGELOG.md
    NEXT_ACTIONS.md
    MEMORY_REGISTER.md
```

## Instructions
1. Use `skill-creator` to create the skill.
2. Define when to register memory: after PDRs, repo migrations, agent dispatches, major architecture decisions, and completed implementation cycles.
3. Include source-of-truth hierarchy rules to avoid conflicting memory.
4. Include clear output templates.
5. Package as `skill.zip`.

## Acceptance Criteria
- Skill can update or generate project state artifacts.
- Skill distinguishes durable decisions from temporary notes.
- Skill includes contradiction handling.
- Skill includes next-action capture.

## Stop Conditions
Stop if:
- The target memory location is unknown and the user expects direct file writes.
- A new entry conflicts with a stronger source of truth.
- The input lacks enough evidence to record a durable decision.
