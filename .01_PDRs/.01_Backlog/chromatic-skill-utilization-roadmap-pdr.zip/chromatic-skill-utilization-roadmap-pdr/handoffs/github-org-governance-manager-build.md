# Agent Handoff: Build `github-org-governance-manager`

## Role
You are acting as a skill designer, GitHub governance planner, and repository migration operator.

## Objective
Create a new skill named `github-org-governance-manager` that standardizes GitHub organization/repository governance, repo transfers, permissions, branch protection, rulesets, repo settings, labels, and post-transfer validation.

## Context
The user has a personal GitHub account and a Poly-Chromatic organization. Several project repos currently live under the personal account and should be migrated or governed under the org when appropriate.

## Inputs
- Prior GitHub org migration PDR package.
- `skill-specs/github-org-governance-manager.spec.md`
- `governance/skill-governance-standard.md`

## Expected Skill Resources

```text
github-org-governance-manager/
  SKILL.md
  agents/openai.yaml
  references/
    repo-transfer-rules.md
    org-settings.md
    repo-settings.md
    branch-protection.md
    permissions-matrix.md
  templates/
    repo-transfer-plan.md
    post-transfer-validation.md
    ruleset-checklist.md
    permission-matrix.md
```

## Instructions
1. Use `skill-creator` to create the skill.
2. Make it clear when the skill should be used: org setup, repo migration, settings audit, permission review, ruleset standardization.
3. Include strong safety rules around destructive settings changes and repo transfers.
4. Prefer producing plans/checklists unless the user explicitly authorizes writes.
5. Package as `skill.zip`.

## Acceptance Criteria
- Skill produces repo transfer plans.
- Skill produces org/repo settings checklists.
- Skill includes post-transfer validation.
- Skill distinguishes personal account repos from org-owned repos.
- Skill includes human approval gates before destructive actions.

## Stop Conditions
Stop if:
- Target organization is unknown.
- Required GitHub permissions are missing.
- Repo transfer would break external integrations without review.
