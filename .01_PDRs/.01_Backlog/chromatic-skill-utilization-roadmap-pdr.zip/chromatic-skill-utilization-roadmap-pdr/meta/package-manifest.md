# Package Manifest

## Package
`chromatic-skill-utilization-roadmap-pdr`

## Created
2026-06-03

## Purpose
Govern the Poly-Chromatic skill ecosystem and define a practical roadmap for skill utilization, cross-LLM/IDE portability, and new skill creation.

## Files

| Path | Purpose |
|---|---|
| `README.md` | Package overview and usage. |
| `docs/PDR-001-skill-utilization-roadmap.md` | Main project design record. |
| `inventory/current-skill-inventory.md` | Known skills and decisions. |
| `inventory/skill-trigger-map.md` | Trigger rules and call order. |
| `roadmap/skill-roadmap.md` | Phased roadmap. |
| `roadmap/cross-llm-ide-portability-plan.md` | Portability model for LLMs and IDEs. |
| `queues/implementation-work-queue.md` | Prioritized implementation tasks. |
| `governance/skill-governance-standard.md` | Skill governance rules. |
| `governance/skill-review-checklist.md` | New/updated skill review checklist. |
| `templates/skill-pdr-template.md` | Template for future skill PDRs. |
| `templates/agent-handoff-template.md` | Generic agent handoff template. |
| `templates/ide-handoff-template.md` | IDE-specific handoff template. |
| `handoffs/llm-ide-handoff-packager-build.md` | Build handoff for first proposed skill. |
| `handoffs/github-org-governance-manager-build.md` | Build handoff for GitHub governance skill. |
| `handoffs/chromatic-memory-registrar-build.md` | Build handoff for memory registrar skill. |
| `skill-specs/llm-ide-handoff-packager.spec.md` | Proposed skill spec. |
| `skill-specs/github-org-governance-manager.spec.md` | Proposed skill spec. |
| `skill-specs/chromatic-memory-registrar.spec.md` | Proposed skill spec. |
| `meta/package-manifest.md` | Manifest. |

## Use Instructions

1. Read the PDR first.
2. Use the trigger map before invoking or creating skills.
3. Build `llm-ide-handoff-packager` first.
4. Use the work queue to create GitHub issues or Codex/Cursor tasks.
5. Re-run a skill utilization audit after the first three proposed skills are built.
