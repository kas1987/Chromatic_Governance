# Chromatic Skill Utilization + Roadmap PDR Package

This package defines a governed operating plan for the Poly-Chromatic skill ecosystem: what exists, what each skill is for, which skills should be promoted or improved, what new skills should be created, and how these skills should support ChatGPT, Claude, Cursor, Codex, Gemini, local LLMs, and IDE-based agent workflows.

## Package Contents

- `docs/PDR-001-skill-utilization-roadmap.md` — main project design record.
- `inventory/current-skill-inventory.md` — known skill catalogue and decision status.
- `inventory/skill-trigger-map.md` — when each skill should be used.
- `roadmap/skill-roadmap.md` — phased implementation roadmap.
- `roadmap/cross-llm-ide-portability-plan.md` — plan for making the skill system useful across LLMs and IDEs.
- `queues/implementation-work-queue.md` — prioritized task queue.
- `governance/skill-governance-standard.md` — naming, scope, ownership, quality, and review rules.
- `governance/skill-review-checklist.md` — review checklist for new and updated skills.
- `templates/skill-pdr-template.md` — reusable PDR template for future skill builds.
- `templates/agent-handoff-template.md` — generic agent/LLM handoff template.
- `templates/ide-handoff-template.md` — Cursor/Codex/IDE handoff template.
- `handoffs/llm-ide-handoff-packager-build.md` — first recommended build handoff.
- `handoffs/github-org-governance-manager-build.md` — second recommended build handoff.
- `handoffs/chromatic-memory-registrar-build.md` — third recommended build handoff.
- `skill-specs/llm-ide-handoff-packager.spec.md` — proposed skill specification.
- `skill-specs/github-org-governance-manager.spec.md` — proposed skill specification.
- `skill-specs/chromatic-memory-registrar.spec.md` — proposed skill specification.
- `meta/package-manifest.md` — package file manifest and usage notes.

## Recommended First Action

Build `llm-ide-handoff-packager` first. It creates the missing bridge between repo/PDR/router outputs and practical execution inside Cursor, Codex, Claude, Gemini, and local IDE agents.

## Operating Principle

Do not create a large number of overlapping skills. Maintain a small governed skill suite where each skill has a precise trigger, clear output contract, and explicit relationship to the broader Poly-Chromatic operating system.
