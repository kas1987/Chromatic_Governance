# Implementation Work Queue

## Queue Rules

Status values:
- `ready`
- `blocked`
- `needs-human-decision`
- `in-progress`
- `review-required`
- `done`

Priority values:
- `p0`: governance/safety/source-of-truth blocker
- `p1`: critical path
- `p2`: important improvement
- `p3`: backlog/polish

## Queue

| ID | Priority | Status | Task | Owner / Model | Inputs | Output | Stop Condition |
|---|---:|---|---|---|---|---|---|
| SKILL-001 | p1 | ready | Build `llm-ide-handoff-packager` skill. | ChatGPT + skill-creator | This PDR package; `llm-ide-handoff-packager.spec.md` | Packaged `skill.zip` | Stop if expected input/output/connectors are unclear. |
| SKILL-002 | p1 | ready | Build `github-org-governance-manager` skill. | ChatGPT + skill-creator | GitHub migration PDR; skill spec | Packaged `skill.zip` | Stop if GitHub permission assumptions are unclear. |
| SKILL-003 | p1 | ready | Build `chromatic-memory-registrar` skill. | ChatGPT + skill-creator | Memory registrar spec | Packaged `skill.zip` | Stop if target memory locations are unknown. |
| SKILL-004 | p2 | ready | Upgrade `repo-pdr-swarm-router` with IDE handoff references. | ChatGPT + skill-creator | Existing router skill; portability plan | Updated `skill.zip` | Stop if existing skill source cannot be accessed. |
| SKILL-005 | p2 | ready | Create a `CHROMATIC_SKILL_MAP.md` source-of-truth file. | ChatGPT | Skill inventory and trigger map | Markdown map | Stop if target repo/path is unknown. |
| SKILL-006 | p2 | ready | Create GitHub issue templates for skill build tasks. | GitHub/Codex/ChatGPT | Queue items | Issue-ready markdown files | Stop if target repo is unknown. |
| SKILL-007 | p2 | ready | Run skill/agent utilization audit after first three builds. | skill-agent-utilization-auditor | Usage logs, agent queues, repo activity | Audit report | Stop if logs are unavailable. |
| SKILL-008 | p3 | ready | Decide whether to merge any repo-tree skills. | chromatic-systems-auditor | Skill source and usage evidence | Keep/merge/retire decision | Stop if usage evidence is missing. |

## Next 3 Actions

1. Build `llm-ide-handoff-packager`.
2. Create `CHROMATIC_SKILL_MAP.md` in the appropriate governance repo.
3. Upgrade `repo-pdr-swarm-router` to explicitly emit target-neutral dispatch packets.
