# Skill Spec: `github-org-governance-manager`

## Name
`github-org-governance-manager`

## Description Draft
Plan, audit, and standardize GitHub organization and repository governance, including personal-to-organization repo transfers, repo ownership decisions, branch protection, rulesets, permissions, teams, labels, repository settings, secrets review, and post-transfer validation. Use when the user wants to move repos into an organization, compare personal vs org ownership, generate settings checklists, audit repo permissions, or create governance-ready migration runbooks.

## Purpose
Make GitHub org/repo governance repeatable and safe.

## Expected Inputs
- Personal account name.
- Organization slug.
- Repo inventory.
- Repo criticality or migration intent.
- Current settings where available.

## Expected Outputs
- Repo transfer plan.
- Org settings checklist.
- Repo settings checklist.
- Branch protection/ruleset checklist.
- Permission matrix.
- Post-transfer validation checklist.
- Migration risk register.

## Safety Rules
- Never transfer, delete, archive, unarchive, or change repository settings without explicit user authorization.
- Prefer planning/checklists when permissions are uncertain.
- Flag integration risks: webhooks, secrets, deploy keys, GitHub Actions, local remotes, package registries, external links.
- Verify target org permissions before recommending execution.

## Example User Requests
- "Move these repos from my personal GitHub to my org."
- "Create org settings for Poly-Chromatic."
- "Audit repo permissions and branch protections."
- "Make a GitHub migration PDR and validation checklist."
