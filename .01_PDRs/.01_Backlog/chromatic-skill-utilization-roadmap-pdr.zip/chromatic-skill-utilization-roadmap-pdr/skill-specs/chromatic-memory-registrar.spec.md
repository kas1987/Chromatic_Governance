# Skill Spec: `chromatic-memory-registrar`

## Name
`chromatic-memory-registrar`

## Description Draft
Capture durable project memory after significant decisions, repo changes, PDRs, migrations, agent dispatches, audits, and implementation cycles. Use when the user wants to update project state, decision registers, changelogs, memory logs, source-of-truth maps, next actions, or continuity notes across ChatGPT, Claude, Codex, Cursor, GitHub, and local repositories.

## Purpose
Prevent loss of continuity across fast-moving multi-system work.

## Expected Inputs
- Event summary.
- Source files or PDR references.
- Decision made.
- Current project state.
- Next action.
- Target memory location if direct file creation/update is requested.

## Expected Outputs
- `PROJECT_STATE.md`
- `DECISIONS.md`
- `CHANGELOG.md`
- `NEXT_ACTIONS.md`
- `MEMORY_REGISTER.md`
- Contradiction notes if applicable.

## Source-of-Truth Hierarchy
1. Explicit user instruction in current task.
2. Current repo source-of-truth docs.
3. PDR decisions.
4. Project state files.
5. Agent logs and handoffs.
6. Chat summaries and inferred memory.

## Safety Rules
- Do not record uncertain inferences as durable facts.
- Label assumptions clearly.
- If new information contradicts stronger source-of-truth material, create a contradiction entry instead of overwriting silently.
- Keep memory concise and actionable.

## Example User Requests
- "Register this decision in project memory."
- "Update the project state after this repo migration."
- "Create a changelog and next actions from this PDR."
- "Save this as durable source-of-truth context."
