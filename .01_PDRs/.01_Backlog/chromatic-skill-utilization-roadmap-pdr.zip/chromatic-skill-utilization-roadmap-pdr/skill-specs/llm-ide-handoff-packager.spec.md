# Skill Spec: `llm-ide-handoff-packager`

## Name
`llm-ide-handoff-packager`

## Description Draft
Convert PDRs, repo-router outputs, project queues, audit findings, and agent tasks into execution-ready handoff packs for Cursor, Codex, Claude, Gemini, GitHub Issues, and local LLM/IDE agents. Use when the user wants to operationalize plans across other LLMs or IDEs, create implementation briefs, generate target-specific task files, or package repo work into portable handoffs with allowed actions, blocked actions, acceptance criteria, validation commands, and stop conditions.

## Purpose
Bridge planning and execution by turning governed work packets into target-specific handoffs.

## Expected Inputs
- PDR package or summary.
- Router dispatch board.
- Queue items.
- Repo path or owner/repo.
- Target environment: Cursor, Codex, Claude, Gemini, GitHub Issue, local LLM, or generic agent.

## Expected Outputs
- Target-specific handoff markdown.
- Optional batch handoff pack.
- GitHub issue bodies.
- IDE task files.
- Validation checklist.

## Target Modes

| Mode | Output |
|---|---|
| Cursor | `.cursor/tasks/*.md` style task packet or generic Cursor handoff. |
| Codex | Implementation handoff with scope, files, tests, and PR notes. |
| Claude | Context-rich review or planning packet. |
| Gemini | Review/comparison brief. |
| GitHub Issue | Issue title/body/labels/acceptance criteria. |
| Local LLM | Compact classification or execution prompt. |

## Required Output Fields
- Task ID
- Title
- Objective
- Context
- Source files
- Allowed actions
- Blocked actions
- Output required
- Acceptance criteria
- Validation commands
- Stop conditions
- Review gate

## Safety Rules
- Do not authorize destructive file/repo operations unless explicitly approved.
- Do not assume hidden context will be available to another LLM.
- Include missing-input blockers instead of guessing.
- Keep each handoff bounded and independently executable.

## Example User Requests
- "Turn this PDR into Cursor tasks."
- "Convert this repo queue into Codex handoffs."
- "Create GitHub issue drafts from this dispatch board."
- "Package these agent tasks for Claude review and Codex implementation."
