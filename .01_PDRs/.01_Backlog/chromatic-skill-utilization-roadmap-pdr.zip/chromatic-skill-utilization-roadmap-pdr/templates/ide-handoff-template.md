# IDE Handoff: [Task Name]

## Target IDE / Agent
[Cursor / Codex / Claude / Gemini / Local LLM / GitHub Issue]

## Repository
[owner/repo or local path]

## Branch
[target branch or new branch convention]

## Objective
[What the IDE agent should accomplish.]

## Files to Inspect First
- [path]

## Files Allowed to Edit
- [path or pattern]

## Files Blocked from Editing
- [path or pattern]

## Implementation Instructions
1. [Step]
2. [Step]
3. [Step]

## Validation Commands
```bash
[command]
```

## Output Required
- Summary of changes.
- Files changed.
- Tests run and results.
- Known limitations.
- Follow-up tasks.

## Acceptance Criteria
- [Criterion]

## Stop Conditions
Stop if:
- Required files are missing.
- Existing architecture conflicts with this task.
- Secrets or credentials are required.
- The change requires destructive migration.
