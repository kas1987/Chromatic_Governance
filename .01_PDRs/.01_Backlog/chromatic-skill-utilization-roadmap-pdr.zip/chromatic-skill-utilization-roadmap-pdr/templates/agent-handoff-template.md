# Agent Handoff: [Task Name]

## Role
You are acting as [planner / implementer / reviewer / auditor / router / packager].

## Objective
[One clear outcome.]

## Context
[Relevant project state, prior decisions, constraints, and source of truth.]

## Inputs
- [File/path/link/snippet]

## Allowed Actions
- [Allowed action]

## Blocked Actions
- [Blocked action]

## Instructions
1. [Step]
2. [Step]
3. [Step]

## Output Required
[Exact output format.]

## Acceptance Criteria
- [Criterion]
- [Criterion]

## Stop Conditions
Stop and report back if:
- Required input is missing.
- A destructive action is needed.
- The task expands beyond scope.
- Tests fail after defined retries.
