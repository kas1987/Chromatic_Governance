# PDR: [Skill Name]

## Status
Draft

## Owner
[Owner]

## Purpose
[What repeatable task this skill solves.]

## Trigger Conditions
Use this skill when:
- [Trigger 1]
- [Trigger 2]
- [Trigger 3]

Do not use this skill when:
- [Non-trigger 1]
- [Non-trigger 2]

## Expected Inputs
- [Input 1]
- [Input 2]

## Expected Outputs
- [Output 1]
- [Output 2]

## Required Connectors / Tools
- [Tool/connector or none]

## Workflow
1. [Step]
2. [Step]
3. [Step]

## References / Templates / Scripts
| Resource | Purpose |
|---|---|
| `[path]` | [Purpose] |

## Acceptance Criteria
- [Criterion]
- [Criterion]

## Stop Conditions
Stop and ask/report if:
- [Condition]
- [Condition]

## Risks
| Risk | Mitigation |
|---|---|
| [Risk] | [Mitigation] |

## Build Notes
[Notes for the skill creator.]
