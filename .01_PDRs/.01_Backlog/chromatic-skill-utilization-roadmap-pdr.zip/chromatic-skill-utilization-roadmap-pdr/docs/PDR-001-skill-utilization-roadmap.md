# PDR-001: Chromatic Skill Utilization + Roadmap

## Status
Draft v1.0

## Date
2026-06-03

## Owner
Kris Sayresmith / Poly-Chromatic

## Purpose
Create a governed plan for the Poly-Chromatic skill ecosystem so ChatGPT and other LLMs/IDE agents can reliably use, extend, route, audit, and package work across repositories, PDRs, agents, queues, and project systems.

## Executive Summary
The current skill set is strong but should be treated as an operating stack, not a loose library. The highest-value move is to promote a small core of orchestration, repo governance, PDR routing, queue dispatch, audit, and artifact-production skills while creating three missing bridge skills:

1. `llm-ide-handoff-packager`
2. `github-org-governance-manager`
3. `chromatic-memory-registrar`

The first skill to build should be `llm-ide-handoff-packager` because it makes `repo-pdr-swarm-router` immediately usable by other LLMs and IDE agents.

## Background
The user operates across many interdependent project systems: GitHub repositories, PDR packages, agent queues, autonomy harnesses, repo trees, implementation plans, documentation packs, and local/hosted LLM environments. The existing skill set already contains valuable specialized workflows, but the skills need a formal trigger map, usage hierarchy, quality standard, and build roadmap.

## Problem Statement
Without a governed skill operating model, the skill library risks becoming fragmented. Similar skills may overlap, new skills may be created too quickly, and outputs may not be portable to IDE agents or other LLMs. This creates friction when moving from planning to execution.

## Goals
- Define the current skill inventory and purpose of each skill.
- Classify skills into operating tiers.
- Identify what to keep, improve, merge, narrow, or create.
- Define a cross-LLM and IDE portability model.
- Create implementation-ready handoffs for the top missing skills.
- Provide a durable work queue and review checklist.

## Non-Goals
- This PDR does not package new executable skills yet.
- This PDR does not modify any GitHub repositories.
- This PDR does not claim all available skills are exhaustively audited from source beyond the currently visible skill list and inspected key skill files.

## Source Context
Known available skills include:

- `skill-creator`
- `repo-pdr-swarm-router`
- `chromatic-systems-auditor`
- `project-level-operator`
- `tree-repo-auditor`
- `repo-tree-architect`
- `cognitive-stack-architect`
- `skill-agent-utilization-auditor`
- `queue-dispatcher`
- `inventory-matrix-manager`
- `github-repo-scout`
- `fusion-computer`

Inspected core skill behavior:

- `repo-pdr-swarm-router` turns large Repo PDR packages into governed, agent-routable work queues with manifests, decision registers, constraint registers, risk registers, dispatch boards, governance gates, and agent handoff packets.
- `project-level-operator` turns goals, project state, repos, notes, and open loops into structured project state, queue, routing, review gates, and execution loops.
- `skill-creator` defines the standard for creating and updating skills, including required `SKILL.md`, optional resources, progressive loading, validation, packaging, and the requirement to output `skill.zip` for skill builds.

## Skill Operating Stack

### Tier 1: Core Command Layer
| Skill | Role | Decision |
|---|---|---|
| `project-level-operator` | Converts broad objectives into project state, queue, routing, guardrails, and review gates. | Promote to core. |
| `repo-pdr-swarm-router` | Converts repo/PDR evidence into governed swarm-ready work packets. | Promote to core and expand with IDE handoff references. |
| `queue-dispatcher` | Selects, routes, and operationalizes next work across agents and repos. | Promote to core. |
| `chromatic-systems-auditor` | Audits systems for alignment, drift, contradictions, governance, and risk. | Promote to core. |
| `fusion-computer` | Produces validated reusable artifacts, manifests, templates, docs, tests, and deployment components. | Promote to core. |

### Tier 2: Repo Governance and Hygiene Layer
| Skill | Role | Decision |
|---|---|---|
| `repo-tree-architect` | Audits and redesigns repo trees, root hygiene, scattered files, and cleanup plans. | Keep. |
| `tree-repo-auditor` | Enforces numbered folder and subfolder standards. | Keep, but narrow trigger to strict numbered-tree governance. |
| `skill-agent-utilization-auditor` | Audits skills, hooks, agents, logs, and usage patterns. | Keep for periodic audits. |

### Tier 3: Discovery, Strategy, and Inventory Layer
| Skill | Role | Decision |
|---|---|---|
| `github-repo-scout` | Finds external GitHub repos/templates/frameworks before building from scratch. | Keep. |
| `inventory-matrix-manager` | Manages files, assets, prompts, workflows, outputs, and registries. | Keep for asset-heavy work. |
| `cognitive-stack-architect` | Organizes nonlinear thinking into structured systems, priorities, and handoffs. | Keep as strategy/front-door skill. |

## Recommended Missing Skills

### 1. `llm-ide-handoff-packager`
Converts PDR/router outputs into execution-ready handoff packages for Cursor, Codex, Claude, Gemini, local LLMs, and GitHub Issues.

### 2. `github-org-governance-manager`
Standardizes GitHub organization/repository migration, permissions, branch protections, rulesets, repo ownership, settings, labels, and transfer validation.

### 3. `chromatic-memory-registrar`
Registers durable decisions, project state, changelogs, memory, next actions, and source-of-truth references after major repo/PDR/agent events.

## Proposed Operating Sequence

```text
1. cognitive-stack-architect
   Use when the project is still conceptual, scattered, or ambiguous.

2. project-level-operator
   Convert the concept into project state, objective, queue, guardrails, and review gates.

3. repo-tree-architect / tree-repo-auditor
   Audit and govern the repository structure.

4. repo-pdr-swarm-router
   Convert repo/PDR evidence into agent-dispatchable work packets.

5. llm-ide-handoff-packager
   Convert work packets into Cursor, Codex, Claude, Gemini, local LLM, and GitHub Issue formats.

6. queue-dispatcher
   Select and route next work.

7. chromatic-systems-auditor
   Review governance, contradictions, evidence, and drift.

8. fusion-computer
   Package reusable artifacts, templates, manifests, docs, and validated components.

9. chromatic-memory-registrar
   Capture durable decisions, changelog entries, project state updates, and next actions.
```

## Design Decisions

### Decision 1: Keep Skills Small and Composable
Do not create one giant master skill. Maintain narrow, composable skills with explicit triggers and output contracts.

### Decision 2: Promote `repo-pdr-swarm-router`
This skill is a cross-LLM execution router, not merely a ChatGPT summarization helper. It should be extended to support IDE and agent handoff outputs.

### Decision 3: Build `llm-ide-handoff-packager` First
This is the highest-leverage missing bridge because it turns existing PDR/router outputs into practical execution artifacts for other tools.

### Decision 4: Treat GitHub Org Governance as a Separate Skill
GitHub repo ownership, org settings, transfer plans, permissions, and branch rules are distinct enough to deserve a dedicated skill.

### Decision 5: Add Memory Registration
Without durable memory registration, major decisions and state transitions will be lost across conversations and tools.

## Risks

| Risk | Severity | Mitigation |
|---|---:|---|
| Skill sprawl | High | Require a PDR and trigger map before creating new skills. |
| Overlap between repo governance skills | Medium | Maintain explicit call order and scope boundaries. |
| IDE handoffs too vague for execution | High | Require acceptance criteria, allowed actions, blocked actions, and stop conditions. |
| Skills become too ChatGPT-specific | Medium | Define generic Markdown outputs usable by Claude, Cursor, Codex, Gemini, and local agents. |
| Missing source-of-truth after execution | High | Create `chromatic-memory-registrar`. |

## Acceptance Criteria
This PDR package is successful when it provides:

- A current skill inventory.
- A trigger map for skill selection.
- A keep/improve/create/merge/retire decision table.
- A phased roadmap.
- A cross-LLM/IDE portability plan.
- A work queue with priorities, owners, and stop conditions.
- Build handoffs for the first three proposed skills.
- Review checklists and governance standards.

## Next Action
Build and package `llm-ide-handoff-packager` as the first new skill.
