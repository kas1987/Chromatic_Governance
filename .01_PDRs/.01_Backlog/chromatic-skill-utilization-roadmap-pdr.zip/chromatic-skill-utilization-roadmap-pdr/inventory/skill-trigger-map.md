# Skill Trigger Map

## Purpose
Define when each skill should be invoked so skill usage remains predictable, composable, and non-overlapping.

## Trigger Rules

| User Need / Signal | Use Skill | Do Not Use When |
|---|---|---|
| "I have a broad idea/project and need to organize it." | `cognitive-stack-architect` | The project already has a clear queue and source of truth. |
| "Turn this into project state / queue / operating plan." | `project-level-operator` | The user only wants a short answer or one-off advice. |
| "Audit this repo tree / organize folders / clean root." | `repo-tree-architect` | The user specifically asks for numbered folder compliance only. |
| "Enforce numbered folder/subfolder standards." | `tree-repo-auditor` | The task is broad repo cleanup without numbered-folder requirement. |
| "Here is a repo PDR / implementation plan / governance pack / audit bundle." | `repo-pdr-swarm-router` | The user wants a normal summary, not execution routing. |
| "Pick the next task / assign work / route queue items." | `queue-dispatcher` | No queue or task context exists yet. Use `project-level-operator` first. |
| "Audit the system / check governance / find contradictions / score alignment." | `chromatic-systems-auditor` | The task is pure implementation without review or governance concern. |
| "Create reusable system artifacts / components / manifests / validated package." | `fusion-computer` | The user wants brainstorming only. |
| "Find an existing GitHub repo/template/framework before we build." | `github-repo-scout` | The user has already selected the stack and needs implementation. |
| "Inventory assets/files/prompts/models/workflows/outputs." | `inventory-matrix-manager` | The task is code repo tree governance. |
| "Audit which skills/agents are used, inactive, redundant, or need pruning." | `skill-agent-utilization-auditor` | The user wants to build a new skill. Use `skill-creator`. |
| "Create/update/package a skill." | `skill-creator` | The user only asks conceptual questions about project operations. |
| "Convert PDR/router outputs into Cursor/Codex/Claude/Gemini handoffs." | `llm-ide-handoff-packager` | Proposed skill; not yet built. |
| "Manage GitHub org/repo transfers/settings/rulesets/permissions." | `github-org-governance-manager` | Proposed skill; not yet built. |
| "Save decisions/project state/changelog/next actions after work." | `chromatic-memory-registrar` | Proposed skill; not yet built. |

## Default Call Order for Repo Work

```text
1. project-level-operator
2. repo-tree-architect
3. tree-repo-auditor, if numbered folder rules apply
4. repo-pdr-swarm-router
5. llm-ide-handoff-packager, once built
6. queue-dispatcher
7. chromatic-systems-auditor
8. fusion-computer
9. chromatic-memory-registrar, once built
```

## Anti-Overlap Rules

- Do not use `repo-pdr-swarm-router` for simple document summaries.
- Do not use `tree-repo-auditor` unless numbered folder governance matters.
- Do not use `github-repo-scout` after the build target has already been selected unless validating build-vs-borrow.
- Do not create a new skill if an existing skill only needs a small reference/template addition.
- Do not merge skills only because they are adjacent; merge only if triggers and output contracts are substantially duplicative.
