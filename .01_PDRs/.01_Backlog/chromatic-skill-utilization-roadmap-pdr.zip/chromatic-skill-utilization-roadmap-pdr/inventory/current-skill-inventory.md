# Current Skill Inventory

## Purpose
Maintain a concise source-of-truth inventory of known skills relevant to the Poly-Chromatic operating system.

## Skill Inventory

| Skill | Primary Function | Tier | Decision | Notes |
|---|---|---:|---|---|
| `skill-creator` | Create, update, validate, and package skills. | Foundation | Keep | Required for all future skill creation/update flows. |
| `project-level-operator` | Convert goals, files, repos, notes, and open loops into project state, queues, routing, and gates. | 1 | Promote | Master project operating layer. |
| `repo-pdr-swarm-router` | Ingest repo/PDR packages, extract decisions/constraints/tasks, apply governance, and route work to agents. | 1 | Promote + expand | Add cross-LLM/IDE handoff modes. |
| `queue-dispatcher` | Select, route, delegate, and operationalize next work across repos and agents. | 1 | Promote | Should consume router output. |
| `chromatic-systems-auditor` | Audit systems, governance, contradictions, drift, standards, risks, and remediation queues. | 1 | Promote | Used at review gates. |
| `fusion-computer` | Create validated reusable components, docs, templates, manifests, tests, and system artifacts. | 1 | Promote | Artifact factory layer. |
| `repo-tree-architect` | Audit and redesign repo trees, root hygiene, scattered files, and cleanup plans. | 2 | Keep | Broad repo structure/design skill. |
| `tree-repo-auditor` | Enforce numbered folder standards and path migrations. | 2 | Keep/narrow | Trigger only for numbered-folder governance. |
| `skill-agent-utilization-auditor` | Audit skill/agent usage, prune inactive agents, analyze logs and queues. | 2 | Keep | Run periodically, not every task. |
| `github-repo-scout` | Find open-source repos, templates, frameworks, and build-vs-borrow options. | 3 | Keep | Use before building from scratch. |
| `inventory-matrix-manager` | Manage inventories of files, assets, prompts, workflows, outputs, generated images, models, and registries. | 3 | Keep | Useful for asset-heavy projects. |
| `cognitive-stack-architect` | Organize scattered nonlinear thinking into structured decisions, systems, priorities, and handoffs. | 3 | Keep | Strong front-door for overload/triage. |

## Proposed New Skills

| Proposed Skill | Purpose | Priority | Rationale |
|---|---|---:|---|
| `llm-ide-handoff-packager` | Convert PDR/router/queue outputs into Cursor/Codex/Claude/Gemini/local-agent handoff packs. | P1 | Highest leverage bridge to execution. |
| `github-org-governance-manager` | Standardize GitHub org/repo settings, transfers, rulesets, permissions, labels, and validation. | P1 | Directly supports personal-to-org repo migration and future governance. |
| `chromatic-memory-registrar` | Register durable decisions, changelogs, project state, next actions, and source-of-truth links. | P1 | Prevents loss of continuity across systems. |

## Current Recommended Stack

```text
strategy/triage:       cognitive-stack-architect
project control:       project-level-operator
repo structure:        repo-tree-architect / tree-repo-auditor
PDR routing:           repo-pdr-swarm-router
next-work dispatch:    queue-dispatcher
system audit:          chromatic-systems-auditor
artifact production:   fusion-computer
external discovery:    github-repo-scout
asset inventory:       inventory-matrix-manager
skill usage audit:     skill-agent-utilization-auditor
skill creation:        skill-creator
```
