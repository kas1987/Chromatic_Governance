# Final Ecosystem Handoff

## Status

This package contains 13 scoped Claude Code plugin families with 113 implemented skill entrypoints. The v14 pass normalized root documentation, completed the RPI lifecycle procedures, added final ecosystem maps, and revalidated structure.

## Recommended first install set

For day-to-day development:

```text
rpi
context-family
qa-eval-family
architecture-family
toolchain-family
```

For safe autonomous/agentic work:

```text
agent-governance-family
security-family
context-family
qa-eval-family
toolchain-family
```

For UI/product work:

```text
product-family
frontend-family
qa-eval-family
docs-family
```

## Before broad use

1. Install only the families needed for the current mission.
2. Run scaffold validation.
3. Run plugin-structure audit.
4. Test 2-3 real workflows per family.
5. Tighten permission policies around any MCP access or external tool calls.

## Known intentional limitations

- Scripts are conservative utility helpers, not full automation engines.
- Hooks are advisory and should be connected to Claude Code lifecycle events according to the target environment.
- MCPs are not bundled by default; add them only inside the family that needs them.
- Skill procedures are written to be portable across IDE agent workflows and may need environment-specific path conventions later.
