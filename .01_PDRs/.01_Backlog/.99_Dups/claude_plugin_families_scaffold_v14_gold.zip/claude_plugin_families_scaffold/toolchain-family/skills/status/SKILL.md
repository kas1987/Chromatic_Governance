---
name: status
description: Generate crisp project, repo, plugin, or agent-workspace status reports. Use when the user asks what state the work is in, what changed, what remains, whether a scaffold is healthy, which branch/worktree is active, or what the next operational move should be.
---

# Status

Report the current operational state of a project or plugin workspace.

## Core procedure

1. Determine the status target: repo, plugin family, sprint, worktree, agent task, or release candidate.
2. Inspect available files and commands when possible: `git status`, recent diffs, validation scripts, manifests, README/PDR updates, and generated artifacts.
3. Classify state using: `green`, `yellow`, `red`, or `unknown`.
4. Report only what affects action: changed files, validation state, blockers, risks, and next move.
5. Keep the top line decision-ready.

## Status levels

- `green`: scoped work is complete, validated, and ready for next stage.
- `yellow`: usable, but has known gaps, unrun checks, or review needs.
- `red`: blocked, failing, unsafe, or structurally incomplete.
- `unknown`: insufficient inspection or no reliable source.

## Output contract

Use `references/status-report-template.md` for formal reports. Otherwise output:

```markdown
## Status

**Overall:** green/yellow/red/unknown
**Current focus:** ...
**Best next move:** ...

### What changed
- ...

### Validation
- ...

### Risks / blockers
- ...

### Next actions
1. ...
2. ...
3. ...
```

## Guardrails

- Do not use `green` if validation has not run and validation is material.
- Do not bury blockers below long narrative.
- Do not confuse artifact existence with artifact quality.

## Related references

- `references/status-report-template.md`
- `references/system-audit-checklist.md`
