---
name: writing-skills
description: Author, update, review, and standardize Claude Code plugin skills and ChatGPT-style SKILL.md files. Use when the user asks to build skills, turn placeholders into usable skill instructions, create reusable workflows, write plugin family skills, validate skill structure, or package skill/plugin authoring conventions.
---

# Writing Skills

Write compact, triggerable, operational skill instructions.

## Core procedure

1. Identify the skill's job: what repeatable task it performs and when it should trigger.
2. Write frontmatter with lowercase `name` and a strong `description` that includes trigger contexts.
3. Keep the body procedural and opinionated. Avoid generic advice.
4. Put reusable templates/checklists in `references/` and link them from the skill.
5. Add scripts only for deterministic, fragile, or repeatedly executed operations.
6. Remove placeholder/example content before marking a skill usable.
7. Validate naming, links, and package structure.

## SKILL.md pattern

```markdown
---
name: short-lowercase-name
description: What this skill does. Use when the user asks to ...
---

# Human Title

One-sentence purpose.

## Core procedure
1. ...

## Output contract
```markdown
...
```

## Guardrails
- ...

## Related references
- `references/...`
```

## Quality bar

A usable skill should answer:

- What triggers this skill?
- What should the agent do first?
- What output should it produce?
- What should it refuse, avoid, or escalate?
- Which references or scripts should it load only when needed?

## Guardrails

- Do not put all knowledge into `SKILL.md`; use references for long templates.
- Do not make descriptions vague. The description is the trigger surface.
- Do not include secrets, private credentials, or environment-specific paths unless they are placeholders.
- Do not over-script reasoning tasks that the model can perform directly.

## Related references

- `references/skill-authoring-standards.md`
- `references/toolchain-operating-model.md`
