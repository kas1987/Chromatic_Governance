---
name: system-audit
description: Audit a plugin scaffold, agent workspace, repo, or toolchain for completeness, consistency, validation readiness, and operational risk. Use when the user asks to check the whole system, validate structure, find missing files, compare manifests to directories, or determine whether the workspace is ready for the next phase.
---

# System Audit

Review workspace integrity and readiness.

## Core procedure

1. Define the audit scope and expected standard: plugin scaffold, repo, release candidate, worktree, or agent workspace.
2. Inspect manifests, root docs, README files, policies, hooks, scripts, skills, agents, and references.
3. Check consistency between indexes and actual files.
4. Run available validators when safe and requested or clearly expected.
5. Classify findings by severity: `critical`, `major`, `minor`, `advisory`.
6. Produce a readiness verdict and remediation list.

## Audit dimensions

Use `references/system-audit-checklist.md` and check:

- structure and required files
- manifest validity
- naming consistency
- skill/reference linkage
- policy and hook presence
- validation scripts and outputs
- stale placeholders
- packaging integrity
- unsafe commands or broad permissions

## Output contract

```markdown
## System audit

**Verdict:** pass / pass-with-warnings / fail / incomplete
**Scope:** ...
**Validation run:** ...

### Findings
| Severity | Area | Finding | Evidence | Fix |
|---|---|---|---|---|

### Readiness gates
- [ ] ...

### Recommended fixes
1. ...
2. ...
3. ...
```

## Guardrails

- Do not mark `pass` when required files are missing or validation failed.
- Do not run destructive remediation without explicit user approval.
- Surface stale placeholder content; it is an operational risk.

## Related references

- `references/system-audit-checklist.md`
- `references/toolchain-operating-model.md`
