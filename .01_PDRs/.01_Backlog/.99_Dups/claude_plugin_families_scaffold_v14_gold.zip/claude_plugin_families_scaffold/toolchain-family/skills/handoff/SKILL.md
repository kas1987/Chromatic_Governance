---
name: handoff
description: Produce operational handoffs for Claude Code, IDE agents, or human engineers when work needs to move between sessions, branches, worktrees, agents, or reviewers. Use when the user asks to prepare a handoff, summarize changed files, package current state, delegate work, resume later, or make another agent productive with minimal context.
---

# Handoff

Create a concrete handoff that another agent or human can execute without guessing.

## Core procedure

1. Identify the receiving audience: human reviewer, coding agent, reviewer agent, release owner, or future session.
2. Inspect the current repo/workspace when available. Prefer actual file paths, command outputs, diffs, tests, and TODO markers over memory.
3. Separate `done`, `in progress`, `not started`, `blocked`, and `needs human decision`.
4. Include exact next commands only when they are safe and scoped.
5. Link the handoff to context-family outputs when present: session brief, decision log, and source-of-truth audit.
6. End with a short continuation plan, not a vague suggestion list.

## Output contract

Use `references/handoff-template.md` for formal handoffs. Otherwise output:

```markdown
## Handoff

**Mission:** ...
**Receiver:** ...
**Current state:** ...
**Best next action:** ...

### Completed
- ...

### Changed files
- `path` - what changed / why it matters

### Validation
- Commands run: ...
- Results: ...
- Not run: ...

### Risks / blockers
- ...

### Next actions
1. ...
2. ...
3. ...
```

## Guardrails

- Do not claim tests, validation, or packaging ran unless confirmed.
- Do not hide uncertainty. Use `unknown` or `not inspected`.
- Do not hand off broad authority. Bound the receiver's scope.
- Escalate if secrets, credentials, production data, or irreversible operations are involved.

## Related references

- `references/handoff-template.md`
- `references/toolchain-operating-model.md`
- `references/status-report-template.md`
