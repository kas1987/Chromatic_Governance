---
name: harvest-insights
description: Convert harvested workspace evidence into prioritized insights, risks, gaps, and next actions. Use after a repo/plugin/worktree harvest, status collection, validation run, or audit scan when the user wants meaning, prioritization, or recommended action rather than raw file inventory.
---

# Harvest Insights

Turn collected operational evidence into decisions.

## Core procedure

1. Start from harvested facts: file paths, diffs, validation output, manifests, TODOs, and docs.
2. Classify each finding as `blocker`, `risk`, `gap`, `opportunity`, `noise`, or `confirmed healthy`.
3. Rank by impact, reversibility, and dependency order.
4. Produce a short action queue with owners or agent roles when relevant.
5. Link findings to status, handoff, system-audit, or release checks as appropriate.

## Prioritization model

Use this scoring when many findings exist:

```text
Priority = impact + urgency + dependency_weight - reversibility
```

- High impact + blocks other work = do first.
- High uncertainty + high blast radius = inspect before changing.
- Low impact + easy fix = batch later.

## Output contract

```markdown
## Harvest insights

**Bottom line:** ...
**Top priority:** ...

### Findings
| Priority | Type | Finding | Evidence | Action |
|---:|---|---|---|---|
| P0 | blocker | ... | `path` / command | ... |

### Recommended action queue
1. ...
2. ...
3. ...

### Defer / ignore
- ...
```

## Guardrails

- Do not overfit from one file if broader inspection is required.
- Do not convert assumptions into facts.
- If evidence is thin, recommend a focused harvest instead of guessing.

## Related references

- `references/harvest-checklist.md`
- `references/status-report-template.md`
- `references/system-audit-checklist.md`
