---
name: using-git-worktrees
description: Plan and manage safe Git worktree workflows for parallel agent work, isolated experiments, feature branches, reviews, and multi-agent sprints. Use when the user asks to split work across agents, avoid branch collisions, create isolated workspaces, compare implementations, or clean up worktrees.
---

# Using Git Worktrees

Use Git worktrees to isolate parallel work without copying repos or causing branch collisions.

## Core procedure

1. Confirm the desired task boundary and branch naming convention.
2. Inspect current repo state before creating or switching worktrees: uncommitted changes, active branch, existing worktrees.
3. Create one worktree per isolated task or agent.
4. Keep each worktree's scope narrow: one feature, one review, one experiment, or one fix.
5. Validate changes inside the worktree before merge or handoff.
6. Clean up worktrees after merge, abandon, or archive.

## Safe command pattern

Use `references/git-worktree-playbook.md` for full workflows. Typical flow:

```bash
git status --short
git worktree list
git worktree add ../repo-task-name -b task/name
cd ../repo-task-name
# work, test, commit or handoff
git worktree remove ../repo-task-name
```

## Branch naming

Prefer:

```text
agent/<family>-<task>
feature/<short-name>
fix/<short-name>
review/<short-name>
experiment/<short-name>
```

## Guardrails

- Do not create a worktree if the current repo has uncommitted changes that may be needed in the new branch without first calling that out.
- Do not reuse one branch for multiple agents.
- Do not delete a worktree unless changes are committed, intentionally discarded, or backed up.
- Do not run cleanup commands with broad wildcards.

## Related references

- `references/git-worktree-playbook.md`
- `references/handoff-template.md`
