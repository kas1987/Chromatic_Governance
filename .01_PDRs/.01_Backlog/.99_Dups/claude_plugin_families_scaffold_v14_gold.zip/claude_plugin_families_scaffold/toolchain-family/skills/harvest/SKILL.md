---
name: harvest
description: Collect useful operational evidence from a repository, plugin scaffold, worktree, or agent workspace. Use when the user asks to gather current state, inspect files, summarize repo contents, capture changes, collect TODOs, or prepare raw material for status, handoff, audit, or planning.
---

# Harvest

Collect high-signal workspace evidence before analysis or delegation.

## Core procedure

1. Define the harvest boundary: full repo, plugin family, changed files, docs, tests, configs, scripts, or agent outputs.
2. Gather structural signals first: tree, manifests, README/PDR, scripts, policies, hooks, skills, tests.
3. Gather change signals second: git status, diffs, untracked files, recently modified files, TODO/FIXME markers.
4. Gather validation signals third: test output, lint output, package/zip integrity, schema checks.
5. Summarize evidence without over-interpreting. Send interpretation to `harvest-insights`, `status`, or `system-audit` when needed.

## Recommended safe commands

Use equivalent IDE or local commands when shell is unavailable:

```bash
git status --short
git diff --stat
git diff --name-only
find . -maxdepth 3 -type f | sort
grep -R "TODO\|FIXME\|HACK\|XXX" -n .
```

Avoid commands that delete, overwrite, deploy, publish, or access secrets.

## Output contract

Use `references/harvest-checklist.md` for structured collection. Report:

```markdown
## Harvest

**Boundary:** ...
**Sources inspected:** ...

### Files / structure
- ...

### Changes
- ...

### Validation signals
- ...

### TODOs / risks found
- ...

### Needs follow-up analysis
- ...
```

## Guardrails

- Do not treat harvested evidence as final review.
- Do not expose secrets. Mask token-like values.
- Do not run broad recursive commands against huge directories without narrowing scope.

## Related references

- `references/harvest-checklist.md`
- `references/toolchain-operating-model.md`
