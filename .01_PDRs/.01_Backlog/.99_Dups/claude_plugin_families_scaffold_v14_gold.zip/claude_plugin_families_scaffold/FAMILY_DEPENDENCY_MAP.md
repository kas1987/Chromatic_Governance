# Family Dependency Map

## Control spine

```text
context-family -> security-family -> qa-eval-family -> architecture-family -> release-family
```

## Execution layer

```text
product-family -> rpi -> architecture-family -> qa-eval-family -> release-family
```

## Operations layer

```text
toolchain-family -> observability-family -> release-family -> docs-family
```

## Multi-agent layer

```text
agent-governance-family -> context-family -> toolchain-family -> rpi
```

## Frontend layer

```text
product-family -> frontend-family -> qa-eval-family -> docs-family -> release-family
```

## Research layer

```text
data-research-family -> product-family -> architecture-family -> rpi
```

## Rule of thumb

- If the task is unclear, start with `context-family` or `rpi/discovery`.
- If the task could cause damage, add `security-family`.
- If the task must be proven correct, add `qa-eval-family`.
- If the task changes structure, add `architecture-family`.
- If the task ships to users, add `release-family`.
- If the task touches UI or assets, add `frontend-family`.
