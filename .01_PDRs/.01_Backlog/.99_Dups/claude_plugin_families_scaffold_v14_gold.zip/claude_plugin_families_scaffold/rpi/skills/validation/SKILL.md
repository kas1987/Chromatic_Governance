---
name: validation
description: Validate whether a completed change satisfies scope, acceptance criteria, and safety expectations. Use when the user asks to validate, check, verify, confirm readiness, or run final gates before handoff or release.
---

# Validation

## Objective

Confirm evidence-backed completion, not just apparent completion.

## Operating procedure

1. Restate acceptance criteria and expected artifacts.
2. Run or inspect available tests, checks, diffs, docs, and generated outputs.
3. Classify results as pass, partial pass, fail, or not tested.
4. List gaps, risks, and exact remediation steps.
5. Only mark ready when evidence supports it.

## Inputs to prefer

- User goal or issue statement
- Relevant repo paths, docs, logs, screenshots, tickets, or diffs
- Constraints, deadlines, permissions, and non-goals
- Acceptance criteria or expected output format

## Output format

Return a compact operator-facing result with:

1. **Outcome** - what was decided, changed, found, or recommended.
2. **Evidence** - files inspected, commands run, facts observed, or sources used.
3. **Risks / gaps** - unresolved questions, assumptions, missing validation, or likely failure points.
4. **Next action** - one specific recommended next step or skill.

## Guardrails

- Do not perform destructive actions without explicit user approval.
- Prefer repository conventions over generic best practices.
- Mark assumptions clearly when evidence is incomplete.
- Use the smallest sufficient scope; escalate to another family when security, architecture, release, QA, frontend, docs, product, observability, or governance concerns dominate.
