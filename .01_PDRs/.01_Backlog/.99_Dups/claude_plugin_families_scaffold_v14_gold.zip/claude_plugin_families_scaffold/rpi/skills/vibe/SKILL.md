---
name: vibe
description: Shape tone, creative direction, UX feel, naming, narrative flavor, or presentation energy for a project artifact. Use when the user asks for vibe, polish, voice, creative direction, UI feel, naming tone, or experience mood.
---

# Vibe

## Objective

Translate intent and emotional direction into usable creative constraints.

## Operating procedure

1. Capture the desired audience, emotional effect, references, and anti-patterns.
2. Create a concise vibe brief with tone words, design cues, interaction feel, and copy guidance.
3. Separate aesthetic preferences from functional requirements.
4. Provide examples and non-examples when helpful.
5. Hand off concrete constraints to product, frontend, docs, or implementation work.

## Inputs to prefer

- User goal or issue statement
- Relevant repo paths, docs, logs, screenshots, tickets, or diffs
- Constraints, deadlines, permissions, and non-goals
- Acceptance criteria or expected output format

## Output format

Return a compact operator-facing result with:

1. **Outcome** - what was decided, changed, found, or recommended.
2. **Evidence** - files inspected, commands run, facts observed, or sources used.
3. **Risks / gaps** - unresolved questions, assumptions, missing validation, or likely failure points.
4. **Next action** - one specific recommended next step or skill.

## Guardrails

- Do not perform destructive actions without explicit user approval.
- Prefer repository conventions over generic best practices.
- Mark assumptions clearly when evidence is incomplete.
- Use the smallest sufficient scope; escalate to another family when security, architecture, release, QA, frontend, docs, product, observability, or governance concerns dominate.
