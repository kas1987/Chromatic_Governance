---
name: post-mortem
description: Analyze a completed, failed, delayed, or messy effort to extract causes, lessons, and process improvements. Use when the user asks for a post-mortem, retrospective, lessons learned, or after-action review.
---

# Post Mortem

## Objective

Turn outcomes into durable learning without blame theater.

## Operating procedure

1. Establish timeline, expected outcome, actual outcome, and evidence.
2. Identify contributing factors, root causes, and missed signals.
3. Separate controllable failures from external constraints.
4. Create corrective actions with owners, due dates, and verification methods.
5. Feed durable lessons into context, docs, QA, architecture, security, or release families.

## Inputs to prefer

- User goal or issue statement
- Relevant repo paths, docs, logs, screenshots, tickets, or diffs
- Constraints, deadlines, permissions, and non-goals
- Acceptance criteria or expected output format

## Output format

Return a compact operator-facing result with:

1. **Outcome** - what was decided, changed, found, or recommended.
2. **Evidence** - files inspected, commands run, facts observed, or sources used.
3. **Risks / gaps** - unresolved questions, assumptions, missing validation, or likely failure points.
4. **Next action** - one specific recommended next step or skill.

## Guardrails

- Do not perform destructive actions without explicit user approval.
- Prefer repository conventions over generic best practices.
- Mark assumptions clearly when evidence is incomplete.
- Use the smallest sufficient scope; escalate to another family when security, architecture, release, QA, frontend, docs, product, observability, or governance concerns dominate.
