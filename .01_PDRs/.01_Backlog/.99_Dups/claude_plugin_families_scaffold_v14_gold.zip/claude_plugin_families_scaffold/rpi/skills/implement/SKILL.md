---
name: implement
description: Implement a scoped code, documentation, configuration, UI, or workflow change after requirements and plan are clear. Use when the user asks to build, add, modify, wire up, create files, or apply a planned change.
---

# Implement

## Objective

Make the requested change while preserving project conventions and validation discipline.

## Operating procedure

1. Confirm scope and acceptance criteria before editing.
2. Inspect relevant files first; do not overwrite unknown local work.
3. Make the smallest coherent change that satisfies the requirement.
4. Update adjacent tests, docs, configs, or examples when the change requires it.
5. Run available validation or explain exactly why it could not be run.

## Inputs to prefer

- User goal or issue statement
- Relevant repo paths, docs, logs, screenshots, tickets, or diffs
- Constraints, deadlines, permissions, and non-goals
- Acceptance criteria or expected output format

## Output format

Return a compact operator-facing result with:

1. **Outcome** - what was decided, changed, found, or recommended.
2. **Evidence** - files inspected, commands run, facts observed, or sources used.
3. **Risks / gaps** - unresolved questions, assumptions, missing validation, or likely failure points.
4. **Next action** - one specific recommended next step or skill.

## Guardrails

- Do not perform destructive actions without explicit user approval.
- Prefer repository conventions over generic best practices.
- Mark assumptions clearly when evidence is incomplete.
- Use the smallest sufficient scope; escalate to another family when security, architecture, release, QA, frontend, docs, product, observability, or governance concerns dominate.
