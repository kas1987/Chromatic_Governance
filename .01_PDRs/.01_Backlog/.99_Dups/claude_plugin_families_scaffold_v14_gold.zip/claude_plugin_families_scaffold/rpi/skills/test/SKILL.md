---
name: test
description: Design or run testing for code, plugins, skills, UI, docs, or agent workflows. Use when the user asks to test, create tests, run checks, verify behavior, or build a test strategy.
---

# Test

## Objective

Create useful evidence that the thing works under expected and edge conditions.

## Operating procedure

1. Identify the unit under test and its expected behavior.
2. Select the right level: static check, unit, integration, e2e, regression, or manual review.
3. Prefer existing test tools and repo conventions.
4. Cover happy path, edge cases, failure modes, and regression risks.
5. Report commands, results, failures, and confidence level.

## Inputs to prefer

- User goal or issue statement
- Relevant repo paths, docs, logs, screenshots, tickets, or diffs
- Constraints, deadlines, permissions, and non-goals
- Acceptance criteria or expected output format

## Output format

Return a compact operator-facing result with:

1. **Outcome** - what was decided, changed, found, or recommended.
2. **Evidence** - files inspected, commands run, facts observed, or sources used.
3. **Risks / gaps** - unresolved questions, assumptions, missing validation, or likely failure points.
4. **Next action** - one specific recommended next step or skill.

## Guardrails

- Do not perform destructive actions without explicit user approval.
- Prefer repository conventions over generic best practices.
- Mark assumptions clearly when evidence is incomplete.
- Use the smallest sufficient scope; escalate to another family when security, architecture, release, QA, frontend, docs, product, observability, or governance concerns dominate.
