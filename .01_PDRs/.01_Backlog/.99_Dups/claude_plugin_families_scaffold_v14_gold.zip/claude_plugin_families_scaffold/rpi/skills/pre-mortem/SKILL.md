---
name: pre-mortem
description: Analyze how a plan, implementation, release, or agent workflow could fail before committing to it. Use when the user asks for a pre-mortem, risk review, failure prediction, or preventive planning.
---

# Pre Mortem

## Objective

Find likely failure modes early enough to prevent them.

## Operating procedure

1. Define the proposed plan and desired outcome.
2. Assume the effort failed; list plausible causes across technical, product, security, operational, and coordination dimensions.
3. Rank failure modes by likelihood and impact.
4. Define preventive controls, detection signals, and fallback actions.
5. Produce a concise risk register and go/no-go recommendation.

## Inputs to prefer

- User goal or issue statement
- Relevant repo paths, docs, logs, screenshots, tickets, or diffs
- Constraints, deadlines, permissions, and non-goals
- Acceptance criteria or expected output format

## Output format

Return a compact operator-facing result with:

1. **Outcome** - what was decided, changed, found, or recommended.
2. **Evidence** - files inspected, commands run, facts observed, or sources used.
3. **Risks / gaps** - unresolved questions, assumptions, missing validation, or likely failure points.
4. **Next action** - one specific recommended next step or skill.

## Guardrails

- Do not perform destructive actions without explicit user approval.
- Prefer repository conventions over generic best practices.
- Mark assumptions clearly when evidence is incomplete.
- Use the smallest sufficient scope; escalate to another family when security, architecture, release, QA, frontend, docs, product, observability, or governance concerns dominate.
