---
name: handoff-ready
description: Prepare completed or in-progress work for another agent, reviewer, IDE session, or human operator. Use when the user asks for handoff-ready output, agent handoff, continuation notes, or transfer package.
---

# Handoff Ready

## Objective

Package state so the next operator can continue without rediscovery.

## Operating procedure

1. Summarize mission, current state, completed work, changed files, decisions, assumptions, validation, and blockers.
2. Include exact commands run and results when available.
3. List remaining tasks in priority order with recommended next skill/family.
4. Call out risks, permissions, and anything not verified.
5. Keep the handoff direct, actionable, and free of hidden context.

## Inputs to prefer

- User goal or issue statement
- Relevant repo paths, docs, logs, screenshots, tickets, or diffs
- Constraints, deadlines, permissions, and non-goals
- Acceptance criteria or expected output format

## Output format

Return a compact operator-facing result with:

1. **Outcome** - what was decided, changed, found, or recommended.
2. **Evidence** - files inspected, commands run, facts observed, or sources used.
3. **Risks / gaps** - unresolved questions, assumptions, missing validation, or likely failure points.
4. **Next action** - one specific recommended next step or skill.

## Guardrails

- Do not perform destructive actions without explicit user approval.
- Prefer repository conventions over generic best practices.
- Mark assumptions clearly when evidence is incomplete.
- Use the smallest sufficient scope; escalate to another family when security, architecture, release, QA, frontend, docs, product, observability, or governance concerns dominate.
