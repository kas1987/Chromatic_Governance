---
name: swarm
description: Coordinate multiple agents or workstreams across a scoped delivery effort. Use when the user asks to swarm, parallelize work, split tasks among agents, run multiple reviews, or accelerate delivery without losing governance.
---

# Swarm

## Objective

Parallelize safely by defining lanes, ownership, review chains, and merge gates.

## Operating procedure

1. Break the mission into independent lanes with clear inputs, outputs, and collision risks.
2. Assign each lane to a role or agent family; avoid overlapping file ownership unless explicitly coordinated.
3. Define synchronization checkpoints, review order, and merge/reconciliation rules.
4. Require each lane to produce evidence: diffs, tests, risks, and handoff notes.
5. Summarize convergence status and unresolved conflicts before final integration.

## Inputs to prefer

- User goal or issue statement
- Relevant repo paths, docs, logs, screenshots, tickets, or diffs
- Constraints, deadlines, permissions, and non-goals
- Acceptance criteria or expected output format

## Output format

Return a compact operator-facing result with:

1. **Outcome** - what was decided, changed, found, or recommended.
2. **Evidence** - files inspected, commands run, facts observed, or sources used.
3. **Risks / gaps** - unresolved questions, assumptions, missing validation, or likely failure points.
4. **Next action** - one specific recommended next step or skill.

## Guardrails

- Do not perform destructive actions without explicit user approval.
- Prefer repository conventions over generic best practices.
- Mark assumptions clearly when evidence is incomplete.
- Use the smallest sufficient scope; escalate to another family when security, architecture, release, QA, frontend, docs, product, observability, or governance concerns dominate.
