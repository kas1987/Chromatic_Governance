---
name: discovery
description: Clarify an ambiguous build, bug, research, or product request before implementation. Use when the user needs discovery, requirement clarification, repo reconnaissance, unknown-risk identification, or a crisp problem statement before planning or coding.
---

# Discovery

## Objective

Convert ambiguity into a bounded mission before any irreversible work.

## Operating procedure

1. Collect the user goal, target repo/scope, constraints, deadline, and definition of success.
2. Inspect available files, tickets, docs, logs, or prior context when available; separate observed facts from assumptions.
3. Identify stakeholders, affected systems, dependencies, risks, non-goals, and unknowns.
4. Ask only blocking questions; otherwise proceed with explicit assumptions.
5. Produce a short discovery brief with problem statement, scope, risks, success criteria, and recommended next skill.

## Inputs to prefer

- User goal or issue statement
- Relevant repo paths, docs, logs, screenshots, tickets, or diffs
- Constraints, deadlines, permissions, and non-goals
- Acceptance criteria or expected output format

## Output format

Return a compact operator-facing result with:

1. **Outcome** - what was decided, changed, found, or recommended.
2. **Evidence** - files inspected, commands run, facts observed, or sources used.
3. **Risks / gaps** - unresolved questions, assumptions, missing validation, or likely failure points.
4. **Next action** - one specific recommended next step or skill.

## Guardrails

- Do not perform destructive actions without explicit user approval.
- Prefer repository conventions over generic best practices.
- Mark assumptions clearly when evidence is incomplete.
- Use the smallest sufficient scope; escalate to another family when security, architecture, release, QA, frontend, docs, product, observability, or governance concerns dominate.
