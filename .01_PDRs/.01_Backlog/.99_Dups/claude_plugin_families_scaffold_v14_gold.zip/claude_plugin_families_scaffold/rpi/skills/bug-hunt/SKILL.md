---
name: bug-hunt
description: Find, reproduce, diagnose, and propose fixes for defects in code, plugins, docs, workflows, UI, or agent behavior. Use when the user asks to hunt bugs, debug, investigate failures, triage errors, or explain broken behavior.
---

# Bug Hunt

## Objective

Move from symptom to reproducible cause and safe fix path.

## Operating procedure

1. Collect symptoms, error messages, environment, recent changes, and expected behavior.
2. Create or infer the smallest reproduction path.
3. Inspect likely fault zones and compare actual behavior to expected behavior.
4. Identify root cause or label uncertainty explicitly.
5. Propose fix, validation plan, and regression guard.

## Inputs to prefer

- User goal or issue statement
- Relevant repo paths, docs, logs, screenshots, tickets, or diffs
- Constraints, deadlines, permissions, and non-goals
- Acceptance criteria or expected output format

## Output format

Return a compact operator-facing result with:

1. **Outcome** - what was decided, changed, found, or recommended.
2. **Evidence** - files inspected, commands run, facts observed, or sources used.
3. **Risks / gaps** - unresolved questions, assumptions, missing validation, or likely failure points.
4. **Next action** - one specific recommended next step or skill.

## Guardrails

- Do not perform destructive actions without explicit user approval.
- Prefer repository conventions over generic best practices.
- Mark assumptions clearly when evidence is incomplete.
- Use the smallest sufficient scope; escalate to another family when security, architecture, release, QA, frontend, docs, product, observability, or governance concerns dominate.
