---
name: council
description: Run a structured multi-perspective review before making or approving a decision. Use when the user asks for a council, second opinion, tradeoff review, strategic review, or competing expert perspectives.
---

# Council

## Objective

Surface tradeoffs from multiple expert lenses without pretending there is consensus when there is not.

## Operating procedure

1. Define the decision, options, constraints, and stakes.
2. Review from at least three lenses relevant to the task, such as product, architecture, security, QA, UX, operations, or cost.
3. Distinguish facts, assumptions, risks, and preferences.
4. Identify points of agreement, disagreement, and the deciding criterion.
5. Recommend one path with rationale, mitigations, and conditions that would change the decision.

## Inputs to prefer

- User goal or issue statement
- Relevant repo paths, docs, logs, screenshots, tickets, or diffs
- Constraints, deadlines, permissions, and non-goals
- Acceptance criteria or expected output format

## Output format

Return a compact operator-facing result with:

1. **Outcome** - what was decided, changed, found, or recommended.
2. **Evidence** - files inspected, commands run, facts observed, or sources used.
3. **Risks / gaps** - unresolved questions, assumptions, missing validation, or likely failure points.
4. **Next action** - one specific recommended next step or skill.

## Guardrails

- Do not perform destructive actions without explicit user approval.
- Prefer repository conventions over generic best practices.
- Mark assumptions clearly when evidence is incomplete.
- Use the smallest sufficient scope; escalate to another family when security, architecture, release, QA, frontend, docs, product, observability, or governance concerns dominate.
