---
name: quick-execute
description: Perform a small, low-risk, well-understood task quickly without a full planning cycle. Use when the user asks for a quick change, small fix, tiny doc update, simple command, or fast bounded execution.
---

# Quick Execute

## Objective

Complete low-risk work fast while still checking for obvious hazards.

## Operating procedure

1. Confirm the task is small, reversible, and low impact.
2. Inspect only the minimum files/context needed.
3. Execute directly; do not expand scope.
4. Run a lightweight check if available.
5. Report what changed, where, and any follow-up needed.

## Inputs to prefer

- User goal or issue statement
- Relevant repo paths, docs, logs, screenshots, tickets, or diffs
- Constraints, deadlines, permissions, and non-goals
- Acceptance criteria or expected output format

## Output format

Return a compact operator-facing result with:

1. **Outcome** - what was decided, changed, found, or recommended.
2. **Evidence** - files inspected, commands run, facts observed, or sources used.
3. **Risks / gaps** - unresolved questions, assumptions, missing validation, or likely failure points.
4. **Next action** - one specific recommended next step or skill.

## Guardrails

- Do not perform destructive actions without explicit user approval.
- Prefer repository conventions over generic best practices.
- Mark assumptions clearly when evidence is incomplete.
- Use the smallest sufficient scope; escalate to another family when security, architecture, release, QA, frontend, docs, product, observability, or governance concerns dominate.
