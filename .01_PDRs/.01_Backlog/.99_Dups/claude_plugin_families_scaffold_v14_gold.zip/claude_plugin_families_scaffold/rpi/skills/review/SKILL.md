---
name: review
description: Review code, docs, plans, diffs, plugin skills, architecture, or outputs before acceptance. Use when the user asks for review, critique, PR review, quality check, or readiness assessment.
---

# Review

## Objective

Assess work against intent, standards, and risk before it is accepted.

## Operating procedure

1. Clarify review target and review lens: correctness, maintainability, security, UX, docs, tests, or release readiness.
2. Inspect evidence, not just summaries.
3. Prioritize findings by severity and actionability.
4. Call out both blocking issues and polish recommendations.
5. End with approve, approve with changes, or do not approve.

## Inputs to prefer

- User goal or issue statement
- Relevant repo paths, docs, logs, screenshots, tickets, or diffs
- Constraints, deadlines, permissions, and non-goals
- Acceptance criteria or expected output format

## Output format

Return a compact operator-facing result with:

1. **Outcome** - what was decided, changed, found, or recommended.
2. **Evidence** - files inspected, commands run, facts observed, or sources used.
3. **Risks / gaps** - unresolved questions, assumptions, missing validation, or likely failure points.
4. **Next action** - one specific recommended next step or skill.

## Guardrails

- Do not perform destructive actions without explicit user approval.
- Prefer repository conventions over generic best practices.
- Mark assumptions clearly when evidence is incomplete.
- Use the smallest sufficient scope; escalate to another family when security, architecture, release, QA, frontend, docs, product, observability, or governance concerns dominate.
