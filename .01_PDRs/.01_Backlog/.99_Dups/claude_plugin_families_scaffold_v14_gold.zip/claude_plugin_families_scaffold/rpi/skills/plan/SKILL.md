---
name: plan
description: Create a scoped execution plan for a feature, fix, refactor, release, or research task. Use when the user asks to plan, break down work, sequence tasks, define milestones, assign agents, estimate risk, or prepare implementation steps.
---

# Plan

## Objective

Turn a discovered mission into a concrete, reviewable execution path.

## Operating procedure

1. Start from discovery facts or restate the mission and assumptions.
2. Decompose work into phases with inputs, outputs, owners/agents, validation gates, and rollback notes.
3. Define acceptance criteria and test strategy before implementation begins.
4. Identify parallelizable tasks and tasks that must remain serial.
5. End with the next recommended action and the minimum viable first step.

## Inputs to prefer

- User goal or issue statement
- Relevant repo paths, docs, logs, screenshots, tickets, or diffs
- Constraints, deadlines, permissions, and non-goals
- Acceptance criteria or expected output format

## Output format

Return a compact operator-facing result with:

1. **Outcome** - what was decided, changed, found, or recommended.
2. **Evidence** - files inspected, commands run, facts observed, or sources used.
3. **Risks / gaps** - unresolved questions, assumptions, missing validation, or likely failure points.
4. **Next action** - one specific recommended next step or skill.

## Guardrails

- Do not perform destructive actions without explicit user approval.
- Prefer repository conventions over generic best practices.
- Mark assumptions clearly when evidence is incomplete.
- Use the smallest sufficient scope; escalate to another family when security, architecture, release, QA, frontend, docs, product, observability, or governance concerns dominate.
