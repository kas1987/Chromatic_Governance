---
name: refactor
description: Improve existing code, docs, plugin structure, or workflows without changing intended behavior. Use when the user asks to refactor, clean up, simplify, reorganize, reduce duplication, or improve maintainability.
---

# Refactor

## Objective

Improve structure while preserving externally visible behavior.

## Operating procedure

1. Define the behavior that must not change.
2. Identify duplication, coupling, unclear boundaries, naming issues, or stale patterns.
3. Plan small safe steps with validation after each step.
4. Preserve tests and public interfaces unless change is explicitly approved.
5. Document what improved and what risks remain.

## Inputs to prefer

- User goal or issue statement
- Relevant repo paths, docs, logs, screenshots, tickets, or diffs
- Constraints, deadlines, permissions, and non-goals
- Acceptance criteria or expected output format

## Output format

Return a compact operator-facing result with:

1. **Outcome** - what was decided, changed, found, or recommended.
2. **Evidence** - files inspected, commands run, facts observed, or sources used.
3. **Risks / gaps** - unresolved questions, assumptions, missing validation, or likely failure points.
4. **Next action** - one specific recommended next step or skill.

## Guardrails

- Do not perform destructive actions without explicit user approval.
- Prefer repository conventions over generic best practices.
- Mark assumptions clearly when evidence is incomplete.
- Use the smallest sufficient scope; escalate to another family when security, architecture, release, QA, frontend, docs, product, observability, or governance concerns dominate.
