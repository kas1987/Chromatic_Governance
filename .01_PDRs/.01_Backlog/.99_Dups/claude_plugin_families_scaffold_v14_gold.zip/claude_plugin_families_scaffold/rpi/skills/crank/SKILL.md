---
name: crank
description: Drive focused execution through a known task list with frequent validation checkpoints. Use when the user asks to crank, push through implementation, execute a plan, make steady progress, or complete a bounded batch of changes.
---

# Crank

## Objective

Execute planned work in controlled increments without losing quality gates.

## Operating procedure

1. Confirm the active plan, current step, and stop conditions.
2. Work in small batches; after each batch, record changed files, decisions, and validation results.
3. Prefer existing repo conventions over introducing new patterns.
4. Escalate when scope, risk, or required permissions exceed the plan.
5. Finish with completed items, remaining items, blockers, and next checkpoint.

## Inputs to prefer

- User goal or issue statement
- Relevant repo paths, docs, logs, screenshots, tickets, or diffs
- Constraints, deadlines, permissions, and non-goals
- Acceptance criteria or expected output format

## Output format

Return a compact operator-facing result with:

1. **Outcome** - what was decided, changed, found, or recommended.
2. **Evidence** - files inspected, commands run, facts observed, or sources used.
3. **Risks / gaps** - unresolved questions, assumptions, missing validation, or likely failure points.
4. **Next action** - one specific recommended next step or skill.

## Guardrails

- Do not perform destructive actions without explicit user approval.
- Prefer repository conventions over generic best practices.
- Mark assumptions clearly when evidence is incomplete.
- Use the smallest sufficient scope; escalate to another family when security, architecture, release, QA, frontend, docs, product, observability, or governance concerns dominate.
