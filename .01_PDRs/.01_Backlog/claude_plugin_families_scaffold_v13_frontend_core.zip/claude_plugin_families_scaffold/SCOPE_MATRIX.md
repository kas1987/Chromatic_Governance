# Scope Matrix

| Work scope | Recommended plugins | Notes |
|---|---|---|
| New feature | `rpi`, `architecture-family`, `qa-eval-family`, `context-family` | Build with design and acceptance gates. |
| Bug fix | `rpi`, `qa-eval-family`, `observability-family` | Start from reproduction and failure analysis. |
| Security review | `security-family`, `architecture-family`, `context-family` | Avoid code modification until risk is understood. |
| Release prep | `release-family`, `qa-eval-family`, `docs-family` | Require rollback and changelog. |
| Research task | `data-research-family`, `product-family` | Prefer read-only evidence gathering. |
| Major refactor | `architecture-family`, `rpi`, `qa-eval-family`, `context-family` | Use worktrees and regression gates. |
| Multi-agent sprint | `agent-governance-family`, `rpi`, `toolchain-family` | Define authority and review chain first. |

| Frontend/UI/UX work | `frontend-family`, `product-family`, `docs-family`, `qa-eval-family` | Use for webpage asset extraction, CSS/Tailwind libraries, dashboards, local GUIs, public UI platforms, and 3D assets. |
