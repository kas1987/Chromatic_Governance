# Claude Code Plugin Families Scaffold

Generated: 2026-06-03

This repository contains scoped Claude Code plugin-family scaffolds. Each plugin is intended to be loaded only when its scope is relevant, avoiding one giant always-on toolkit.

## Included plugin families

- `rpi` - Full research, planning, implementation, review, and iteration lifecycle for scoped delivery work.
- `toolchain-family` - Infrastructure and authoring utilities for agent workspaces, handoffs, audits, harvesting, and repo operations.
- `security-family` - Security, trust-boundary, secrets, prompt-injection, and permission review controls for agentic development.
- `context-family` - Context, memory, decision log, source-of-truth, and session handoff controls.
- `architecture-family` - Design governance for architecture, interfaces, module boundaries, ADRs, migrations, and technical debt.
- `qa-eval-family` - Testing, acceptance criteria, regression harnesses, LLM/agent evals, golden cases, and failure analysis.
- `release-family` - Release planning, changelogs, versioning, rollout, deployment checks, rollback, and post-release monitoring.
- `observability-family` - Logs, metrics, tracing, incident summaries, RCA, SLO checks, alert tuning, and health reports.
- `data-research-family` - Evidence gathering, source scans, benchmarks, documentation digests, API change watches, and citation audits.
- `product-family` - Requirements, user stories, MVP planning, prioritization, UX critique, and feedback-to-backlog conversion.
- `docs-family` - Documentation operations for README, API docs, runbooks, dev guides, troubleshooting, diagrams, and doc audits.
- `agent-governance-family` - Multi-agent delegation, authority maps, conflict resolution, review chains, parallel planning, and escalation policy.

## Structure rule

Each plugin keeps metadata in `.claude-plugin/plugin.json` and places components at plugin root level:

```text
plugin-name/
  .claude-plugin/plugin.json
  README.md
  LICENSE
  skills/<skill-name>/SKILL.md
  agents/<agent-name>.md
  hooks/hooks.json
  scripts/*.sh
  policies/*.md
```

## Suggested use

Load plugins by mission, not by habit. For example:

- Feature build: `rpi`, `architecture-family`, `qa-eval-family`, `context-family`
- Security review: `security-family`, `architecture-family`, `context-family`
- Release prep: `release-family`, `qa-eval-family`, `docs-family`
- Multi-agent sprint: `agent-governance-family`, `rpi`, `toolchain-family`

## Next phase

The scaffolds include placeholder SKILL.md files. Build the actual skill procedures next, then run the PDR checklist in `PDR.md` before publishing or installing broadly.

- `frontend-family`: Frontend/UI/UX, CSS/Tailwind/component libraries, dashboards, local apps, public UI platforms, webpage asset extraction, and Blender/3D assets.
